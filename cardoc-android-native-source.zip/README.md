# CarDoc Android Native

Initial native Android wrapper for the existing CarDoc UI.

Features:
- Existing CarDoc garage, code database and symptom diagnosis UI
- Native Android Bluetooth Classic discovery
- ELM327 SPP/RFCOMM connection (UUID 00001101-0000-1000-8000-00805F9B34FB)
- Automatic Mode 03 stored engine DTC read
- Mode 04 engine/emissions DTC clear after the existing double confirmation in the UI
- Web BLE fallback remains in the bundled UI

The initial build intentionally targets generic engine/emissions OBD-II. It does not send manufacturer-specific ABS/SRS clear commands.


v1.1: Fixed bundled codes.json/symptoms.json loading inside Android WebView by using the native Android bridge.


v1.2: Embedded OBD code and symptom databases directly in the Android HTML to guarantee offline/native loading.


v1.3: Added offline illustrated likely-part cards for 21 common OBD-II codes.


v1.4: Embedded parts-map directly in HTML so related-part illustrations always appear in Android WebView.


v1.5: Replaced the first 10 schematic part illustrations with realistic offline product-style photos.


v1.6: Replaced all 17 supported part illustrations with realistic offline product-style images.


v1.7: All 159 bundled OBD-II codes now map to likely inspection parts. Added 10 more realistic offline component photos and multilingual universal-photo disclaimer.


v1.8: Removed baked-in Georgian text from all grid-derived realistic part images. Only the app's dynamic multilingual labels remain.


v1.9: Added explicit green/red OBD connection indicator and automatic live-data dashboard (RPM, speed, coolant, oil temp when supported, voltage, load, throttle, intake temp, MAP, MAF, fuel level, fuel trims and timing).
