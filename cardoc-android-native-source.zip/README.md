# CarDoc Android Native

Initial native Android wrapper for the existing CarDoc UI.

Features:
- Existing CarDoc garage, code database and symptom diagnosis UI
- Native Android Bluetooth Classic discovery
- ELM327 SPP/RFCOMM connection (UUID 00001101-0000-1000-8000-00805F9B34FB)
- Automatic Mode 03 stored engine DTC read
- Mode 04 engine/emissions DTC clear after the existing double confirmation in the UI
- Web BLE fallback remains in the bundled UI

The initial build intentionally targets generic engine/emissions OBD-II. It does not send manufacturer-specific ABS/SRS clear commands.


v1.1: Fixed bundled codes.json/symptoms.json loading inside Android WebView by using the native Android bridge.


v1.2: Embedded OBD code and symptom databases directly in the Android HTML to guarantee offline/native loading.


v1.3: Added offline illustrated likely-part cards for 21 common OBD-II codes.


v1.4: Embedded parts-map directly in HTML so related-part illustrations always appear in Android WebView.
