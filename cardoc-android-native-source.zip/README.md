# CarDoc Android Native

Initial native Android wrapper for the existing CarDoc UI.

Features:
- Existing CarDoc garage, code database and symptom diagnosis UI
- Native Android Bluetooth Classic discovery
- ELM327 SPP/RFCOMM connection (UUID 00001101-0000-1000-8000-00805F9B34FB)
- Automatic Mode 03 stored engine DTC read
- Mode 04 engine/emissions DTC clear after the existing double confirmation in the UI
- Web BLE fallback remains in the bundled UI

The initial build intentionally targets generic engine/emissions OBD-II. It does not send manufacturer-specific ABS/SRS clear commands.


v1.1: Fixed bundled codes.json/symptoms.json loading inside Android WebView by using the native Android bridge.


v1.2: Embedded OBD code and symptom databases directly in the Android HTML to guarantee offline/native loading.


v1.3: Added offline illustrated likely-part cards for 21 common OBD-II codes.


v1.4: Embedded parts-map directly in HTML so related-part illustrations always appear in Android WebView.


v1.5: Replaced the first 10 schematic part illustrations with realistic offline product-style photos.


v1.6: Replaced all 17 supported part illustrations with realistic offline product-style images.


v1.7: All 159 bundled OBD-II codes now map to likely inspection parts. Added 10 more realistic offline component photos and multilingual universal-photo disclaimer.


v1.8: Removed baked-in Georgian text from all grid-derived realistic part images. Only the app's dynamic multilingual labels remain.


v1.9: Added explicit green/red OBD connection indicator and automatic live-data dashboard (RPM, speed, coolant, oil temp when supported, voltage, load, throttle, intake temp, MAP, MAF, fuel level, fuel trims and timing).


v1.10: Replaced the Maintenance home card with Vehicle Gauges / Live Data. Tapping it opens the live metrics panel; its Close button only collapses the panel and does not exit the app. Removed the redundant 'Show all Bluetooth devices' button.


v1.11: Improved real-vehicle OBD communication, especially slower ISO/KWP vehicles. The app now establishes the ECU protocol with 0100 before reporting a successful OBD connection, uses longer Mode 03/04 timeouts, pauses live PID polling while reading/clearing DTCs, and shows the detected ELM protocol when available.


v1.12: Expanded offline OBD-II database from 159 to 226 codes, especially P01xx/O2/fuel codes. P0145 now has EN/KA/RU explanation and O2-sensor photo mapping.


v1.13: Added universal OBD-II protocol scanning. The app now explicitly tests CAN 11/500, CAN 29/500, CAN 11/250, CAN 29/250, KWP2000 Fast, KWP2000 5-baud, ISO 9141-2, J1850 PWM and J1850 VPW, then falls back to ELM327 automatic detection. Connection is accepted only after a valid ECU PID response.


v1.14: Added make-aware manufacturer-specific DTC interpretation for Honda, Nissan, Toyota and Mazda. The active vehicle in My Garage selects the manufacturer database for P1xxx codes; the UI labels these definitions as manufacturer-specific and warns that exact meanings can vary by model/year. Starter database contains 26 verified/common manufacturer codes and maps relevant likely parts.


v1.15: Added advanced OBD-II diagnostics: Mode 07 pending DTCs, Mode 0A permanent DTCs, Mode 02 freeze-frame values, Mode 01 PID 01 readiness monitors, and Mode 09 PID 02 VIN reading. VIN is read automatically after a successful connection and saved to the active Garage vehicle when available. Unsupported standard services show an unavailable/N/A result instead of being treated as a connection failure.


v1.16: Optimized Live Data polling for lower latency. RPM and speed are polled every cycle, driving-response PIDs every 2 cycles, and slow-changing PIDs every 5 cycles. Live PID timeout reduced to 900 ms and loop pause reduced to 90 ms. Removed the Install/Download CarDoc box from the app UI; the OBD disconnect button remains in the OBD panel.


v1.17: Removed the OBD Disconnect button from the OBD panel and added a Lobby Exit button that closes the native Android app. Live Data scheduling was reworked for lower gauge latency: RPM and speed are sent to the UI immediately after each ECU reply, while only one slower PID is polled between fast cycles. Live PID timeout is now 700 ms with a 25 ms loop pause. Added a Lambda/O2 mixture live value using standard PID 24 when available, falling back to PID 44. Direct CO concentration is intentionally not displayed because Generic OBD-II does not provide a universal CO ppm/% PID; a gas analyzer or make-specific data is required for a true CO reading.


v1.18:
- Separate in-app page views for main menu panels.
- Back returns to lobby without closing OBD; Exit is the explicit socket/app close action.
- Live normal/reference labels and red out-of-range highlighting.
- More RPM/speed polling priority, especially on CAN.


v1.19:
- Fixed reconnect regression after returning to the lobby. If the native Bluetooth/OBD socket is still connected, reopening OBD2 now reuses the existing socket instead of opening a Bluetooth scan and tearing down the live connection.
- Added native bridge connection-state/device/protocol getters so the UI can restore connected state without reconnecting.
- Fixed Live Data stop/start race with a session token, so leaving Live Data and opening it again does not let an old worker stop the new polling session.
- OBD remains connected until the explicit Exit action or a real socket failure.


v1.20:
- Added native Wi-Fi ELM327/TCP support alongside Bluetooth Classic. The app tries the current Wi-Fi gateway plus common ELM327 endpoints/ports (35000 and 23).
- OBD screen now lets the user choose Bluetooth or Wi-Fi; reopening the screen reuses an existing connection.
- Added build-time download of an extended offline SQLite DTC database from Wal33D/dtc-database (MIT licensed). If available during build, the APK contains 18k+ English DTC definitions across generic and manufacturer-specific entries.
- CarDoc's existing translated EN/KA/RU definitions remain preferred; the extended database is used as a large fallback and uses active Garage make for manufacturer-specific lookup.
- Database presence does not itself add ABS/Airbag module scanning; those ECUs can require manufacturer-specific communication beyond generic Mode 03.


## v1.21 Pro features
- Diagnostic history with shareable text reports
- Live graphs, HUD, trip computer, 0–100 timer, customizable dashboard
- Mode 06 read-only monitor-test access
- Adapter test (ATI / voltage / protocol / ECU probe)
- Last-adapter reconnect and auto-reconnect toggle
- Preferred OBD protocol profile
- Custom read-only PID/DID reader; write/clear/coding/actuator services are blocked

Manufacturer-specific ABS/Airbag/steering coding and active tests are intentionally not sent generically; those need validated vehicle-specific profiles.


v1.22: Replaced My Garage / Add car with a single current-vehicle search/selection screen. Make/model suggestions are loaded from the public NHTSA vPIC API when internet is available; a common-make fallback and manual entry remain available offline. Existing v1.21 saved active car is migrated automatically. No multi-car add/delete flow remains.


CarDoc v1.23: corrected vehicle make/model catalogue. Uses a curated passenger-car make list instead of vPIC GetAllMakes; common models are bundled offline and extra models load online per selected make.


## CarDoc v1.24
- Removed Symptoms card from the home menu; OBD2 now occupies that slot.
- Added an original inline SVG vehicle illustration to Vehicle Search.
- Fixed Android WebView language switching by using explicit DOM lookups and complete fallback merging.
- Added Turkish, Azerbaijani, Armenian, and Ukrainian UI languages alongside English, Georgian, and Russian.
- Expanded Georgian Wi-Fi/manufacturer-specific UI strings and translated vehicle-selection/fuel controls.
