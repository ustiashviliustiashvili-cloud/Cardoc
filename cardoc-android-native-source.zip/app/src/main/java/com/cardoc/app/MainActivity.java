package com.cardoc.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_BT_PERMS = 101;
    private static final int REQ_ENABLE_BT = 102;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private WebView webView;
    private BluetoothAdapter btAdapter;
    private BluetoothSocket btSocket;
    private InputStream btIn;
    private OutputStream btOut;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    private final List<BluetoothDevice> foundDevices = new ArrayList<>();
    private final Set<String> foundAddresses = new HashSet<>();
    private ArrayAdapter<String> deviceListAdapter;
    private AlertDialog deviceDialog;
    private Runnable pendingPermissionAction;
    private boolean receiverRegistered = false;
    private String connectedName = "OBD2";

    private final BroadcastReceiver btReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device;
                if (Build.VERSION.SDK_INT >= 33) {
                    device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
                } else {
                    device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                }
                if (device != null) addDevice(device);
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                jsStatus("Scan finished. Select your OBD2 adapter.", false);
            }
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        btAdapter = manager != null ? manager.getAdapter() : null;

        webView = new WebView(this);
        setContentView(webView);
        webView.setBackgroundColor(0xFF08111F);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowFileAccessFromFileURLs(true);
        webView.getSettings().setAllowUniversalAccessFromFileURLs(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new ObdBridge(), "AndroidOBD");
        webView.loadUrl("file:///android_asset/index.html");

        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(btReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(btReceiver, filter);
        }
        receiverRegistered = true;
    }

    public class ObdBridge {
        @JavascriptInterface public void scanBluetooth() {
            main.post(() -> ensureBluetoothReady(MainActivity.this::showDevicePicker));
        }

        @JavascriptInterface public void readCodes() {
            readCodesNative();
        }

        @JavascriptInterface public void clearCodes() {
            clearCodesNative();
        }

        @JavascriptInterface public void disconnect() {
            disconnectNative(true);
        }
    }

    private void ensureBluetoothReady(Runnable action) {
        if (btAdapter == null) {
            jsError("Bluetooth is not available on this device.");
            return;
        }
        if (!hasBtPermissions()) {
            pendingPermissionAction = action;
            requestBtPermissions();
            return;
        }
        if (!btAdapter.isEnabled()) {
            pendingPermissionAction = action;
            try {
                startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_ENABLE_BT);
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            }
            return;
        }
        action.run();
    }

    private boolean hasBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT_PERMS);
        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_BT_PERMS);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT_PERMS) {
            if (hasBtPermissions()) {
                Runnable r = pendingPermissionAction;
                pendingPermissionAction = null;
                if (r != null) ensureBluetoothReady(r);
            } else {
                jsError("Bluetooth permission is required to find the OBD2 adapter.");
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_ENABLE_BT) {
            Runnable r = pendingPermissionAction;
            pendingPermissionAction = null;
            if (btAdapter != null && btAdapter.isEnabled() && r != null) r.run();
            else jsError("Bluetooth is turned off.");
        }
    }

    private void showDevicePicker() {
        foundDevices.clear();
        foundAddresses.clear();

        ListView listView = new ListView(this);
        deviceListAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_2, android.R.id.text1, new ArrayList<>());
        listView.setAdapter(deviceListAdapter);

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("Select OBD2 Bluetooth device")
                .setView(listView)
                .setNegativeButton("Cancel", (d, w) -> stopDiscovery());
        deviceDialog = builder.create();
        deviceDialog.setOnDismissListener(d -> stopDiscovery());
        deviceDialog.show();

        // Paired devices appear immediately.
        try {
            Set<BluetoothDevice> bonded = btAdapter.getBondedDevices();
            if (bonded != null) {
                List<BluetoothDevice> sorted = new ArrayList<>(bonded);
                sortObdFirst(sorted);
                for (BluetoothDevice d : sorted) addDevice(d);
            }
        } catch (SecurityException ignored) {}

        listView.setOnItemClickListener((parent, view, position, id) -> {
            if (position < 0 || position >= foundDevices.size()) return;
            BluetoothDevice selected = foundDevices.get(position);
            stopDiscovery();
            if (deviceDialog != null) deviceDialog.dismiss();
            connectClassic(selected);
        });

        jsStatus("Searching Bluetooth devices…", false);
        try {
            if (btAdapter.isDiscovering()) btAdapter.cancelDiscovery();
            btAdapter.startDiscovery();
        } catch (SecurityException e) {
            jsError("Bluetooth scan permission is missing.");
        }
    }

    private void addDevice(BluetoothDevice device) {
        main.post(() -> {
            try {
                String address = device.getAddress();
                if (address == null || foundAddresses.contains(address)) return;
                String name = device.getName();
                if (name == null || name.trim().isEmpty()) name = "Unknown Bluetooth device";

                // Put OBD-like names near the top while still showing all Classic devices.
                int insertAt = looksLikeObd(name) ? firstNonObdIndex() : foundDevices.size();
                foundAddresses.add(address);
                foundDevices.add(insertAt, device);
                deviceListAdapter.insert(name + "\n" + address, insertAt);
                deviceListAdapter.notifyDataSetChanged();
            } catch (SecurityException ignored) {}
        });
    }

    private int firstNonObdIndex() {
        for (int i = 0; i < foundDevices.size(); i++) {
            try {
                String n = foundDevices.get(i).getName();
                if (!looksLikeObd(n)) return i;
            } catch (SecurityException e) { return i; }
        }
        return foundDevices.size();
    }

    private boolean looksLikeObd(String name) {
        if (name == null) return false;
        String n = name.toUpperCase(Locale.ROOT);
        return n.contains("OBD") || n.contains("ELM") || n.contains("V-LINK") || n.contains("VLINK")
                || n.contains("VGATE") || n.contains("ICAR") || n.contains("VIECAR") || n.contains("VEEPEAK")
                || n.contains("KONNWEI") || n.contains("CARISTA");
    }

    private void sortObdFirst(List<BluetoothDevice> list) {
        Collections.sort(list, (a,b) -> {
            try {
                boolean ao = looksLikeObd(a.getName());
                boolean bo = looksLikeObd(b.getName());
                if (ao == bo) return 0;
                return ao ? -1 : 1;
            } catch (SecurityException e) { return 0; }
        });
    }

    private void stopDiscovery() {
        try {
            if (btAdapter != null && btAdapter.isDiscovering()) btAdapter.cancelDiscovery();
        } catch (SecurityException ignored) {}
    }

    private void connectClassic(BluetoothDevice device) {
        jsStatus("Connecting to OBD2…", false);
        io.execute(() -> {
            disconnectSocketOnly();
            stopDiscovery();
            BluetoothSocket socket = null;
            Exception last = null;

            try {
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                socket.connect();
            } catch (Exception e) {
                last = e;
                closeQuietly(socket);
                try {
                    socket = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
                    socket.connect();
                } catch (Exception e2) {
                    last = e2;
                    closeQuietly(socket);
                    socket = null;
                }
            }

            if (socket == null || !socket.isConnected()) {
                jsError("Could not connect to this Bluetooth device. Pair the OBD2 adapter in Android Bluetooth settings first, then try again.");
                return;
            }

            try {
                btSocket = socket;
                btIn = socket.getInputStream();
                btOut = socket.getOutputStream();
                try { connectedName = device.getName(); } catch (SecurityException ignored) { connectedName = "OBD2"; }
                if (connectedName == null || connectedName.trim().isEmpty()) connectedName = "OBD2";

                sendElm("ATZ", 2800);
                sendElm("ATE0", 1200);
                sendElm("ATL0", 1200);
                sendElm("ATS0", 1200);
                sendElm("ATH0", 1200);
                sendElm("ATSP0", 1800);

                jsCall("nativeObdConnected(" + JSONObject.quote(connectedName) + ")");
                readCodesNative();
            } catch (Exception e) {
                jsError("Connected to Bluetooth, but the OBD2 adapter did not respond as an ELM327/SPP device.");
                disconnectSocketOnly();
            }
        });
    }

    private void readCodesNative() {
        io.execute(() -> {
            if (!isSocketConnected()) {
                jsError("OBD2 is not connected.");
                return;
            }
            try {
                jsStatus("Reading stored engine trouble codes…", true);
                String raw = sendElm("03", 4200);
                List<String> codes = decodeDtcs(raw);
                JSONArray arr = new JSONArray();
                for (String code : codes) arr.put(code);
                jsCall("nativeObdCodes(" + arr.toString() + ")");
            } catch (Exception e) {
                jsError("Could not read OBD2 codes.");
            }
        });
    }

    private void clearCodesNative() {
        io.execute(() -> {
            if (!isSocketConnected()) {
                jsError("OBD2 is not connected.");
                return;
            }
            try {
                jsStatus("Clearing stored engine/emissions codes…", true);
                sendElm("04", 4200);
                Thread.sleep(1200);
                String raw = sendElm("03", 4200);
                List<String> codes = decodeDtcs(raw);
                JSONArray arr = new JSONArray();
                for (String code : codes) arr.put(code);
                jsCall("nativeObdCodes(" + arr.toString() + ")");
            } catch (Exception e) {
                jsError("Could not clear the codes.");
            }
        });
    }

    private synchronized String sendElm(String command, long timeoutMs) throws Exception {
        if (!isSocketConnected() || btIn == null || btOut == null) throw new IllegalStateException("Not connected");

        while (btIn.available() > 0) {
            byte[] junk = new byte[Math.min(512, btIn.available())];
            btIn.read(junk);
        }

        btOut.write((command + "\r").getBytes(StandardCharsets.US_ASCII));
        btOut.flush();

        StringBuilder out = new StringBuilder();
        long end = System.currentTimeMillis() + timeoutMs;
        byte[] buffer = new byte[512];
        while (System.currentTimeMillis() < end) {
            int available = btIn.available();
            if (available > 0) {
                int n = btIn.read(buffer, 0, Math.min(buffer.length, available));
                if (n > 0) {
                    out.append(new String(buffer, 0, n, StandardCharsets.US_ASCII));
                    if (out.indexOf(">") >= 0) break;
                }
            } else {
                Thread.sleep(40);
            }
        }
        if (out.length() == 0) throw new Exception("OBD timeout");
        return out.toString();
    }

    private List<String> decodeDtcs(String raw) {
        List<String> codes = new ArrayList<>();
        if (raw == null) return codes;

        String upper = raw.toUpperCase(Locale.ROOT)
                .replace("SEARCHING...", " ")
                .replace("SEARCHING", " ")
                .replace("NO DATA", " ")
                .replace(">", " ");

        // ATH0 is requested above, so common ELM327 replies look like: 43 01 71 00 00 ...
        String[] parts = upper.split("[^0-9A-F]+");
        List<String> bytes = new ArrayList<>();
        for (String p : parts) if (p.matches("[0-9A-F]{2}")) bytes.add(p);

        for (int i = 0; i < bytes.size(); i++) {
            if (!"43".equals(bytes.get(i))) continue;
            int j = i + 1;
            while (j + 1 < bytes.size()) {
                if ("43".equals(bytes.get(j))) break;
                int a, b;
                try {
                    a = Integer.parseInt(bytes.get(j), 16);
                    b = Integer.parseInt(bytes.get(j + 1), 16);
                } catch (Exception e) { break; }
                if (a == 0 && b == 0) break;
                String dtc = decodeDtcPair(a, b);
                if (dtc != null && !codes.contains(dtc)) codes.add(dtc);
                j += 2;
            }
        }
        return codes;
    }

    private String decodeDtcPair(int a, int b) {
        char[] systems = {'P','C','B','U'};
        char system = systems[(a >> 6) & 0x03];
        int digit1 = (a >> 4) & 0x03;
        int digit2 = a & 0x0F;
        int digit3 = (b >> 4) & 0x0F;
        int digit4 = b & 0x0F;
        return "" + system + digit1 + Integer.toHexString(digit2).toUpperCase(Locale.ROOT)
                + Integer.toHexString(digit3).toUpperCase(Locale.ROOT)
                + Integer.toHexString(digit4).toUpperCase(Locale.ROOT);
    }

    private boolean isSocketConnected() {
        return btSocket != null && btSocket.isConnected();
    }

    private void disconnectNative(boolean notifyJs) {
        io.execute(() -> {
            disconnectSocketOnly();
            if (notifyJs) jsCall("nativeObdDisconnected()");
        });
    }

    private void disconnectSocketOnly() {
        try { if (btIn != null) btIn.close(); } catch (Exception ignored) {}
        try { if (btOut != null) btOut.close(); } catch (Exception ignored) {}
        closeQuietly(btSocket);
        btIn = null; btOut = null; btSocket = null;
    }

    private void closeQuietly(BluetoothSocket socket) {
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
    }

    private void jsStatus(String message, boolean connected) {
        jsCall("nativeObdStatus(" + JSONObject.quote(message) + "," + connected + ")");
    }

    private void jsError(String message) {
        jsCall("nativeObdError(" + JSONObject.quote(message) + ")");
    }

    private void jsCall(String code) {
        main.post(() -> webView.evaluateJavascript("window." + code, null));
    }

    @Override protected void onDestroy() {
        stopDiscovery();
        disconnectSocketOnly();
        io.shutdownNow();
        if (receiverRegistered) {
            try { unregisterReceiver(btReceiver); } catch (Exception ignored) {}
        }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
