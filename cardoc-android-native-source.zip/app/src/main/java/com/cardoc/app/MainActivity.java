package com.cardoc.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.net.DhcpInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_BT_PERMS = 101;
    private static final int REQ_ENABLE_BT = 102;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final UUID NUS_SERVICE_UUID = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID NUS_WRITE_UUID = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID NUS_NOTIFY_UUID = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID HM10_SERVICE_UUID = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb");
    private static final UUID HM10_CHAR_UUID = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb");
    private static final UUID FFF0_SERVICE_UUID = UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb");
    private static final UUID FFF1_CHAR_UUID = UUID.fromString("0000fff1-0000-1000-8000-00805f9b34fb");
    private static final UUID FFF2_CHAR_UUID = UUID.fromString("0000fff2-0000-1000-8000-00805f9b34fb");
    private static final UUID CCCD_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final String ACTION_USB_PERMISSION = "com.cardoc.app.USB_PERMISSION";

    private WebView webView;
    private BluetoothAdapter btAdapter;
    private BluetoothSocket btSocket;
    private InputStream btIn;
    private OutputStream btOut;

    private BluetoothGatt bleGatt;
    private BluetoothGattCharacteristic bleWriteChar;
    private BluetoothGattCharacteristic bleNotifyChar;
    private BluetoothLeScanner bleScanner;
    private ScanCallback bleScanCallback;
    private volatile boolean bleReady = false;
    private final Object bleBufferLock = new Object();
    private final StringBuilder bleBuffer = new StringBuilder();
    private final Object bleWriteLock = new Object();
    private volatile boolean bleWriteDone = false;
    private volatile boolean bleWriteOk = false;
    private final List<BluetoothDevice> foundBleDevices = new ArrayList<>();
    private final Set<String> foundBleAddresses = new HashSet<>();
    private ArrayAdapter<String> bleListAdapter;
    private AlertDialog bleDialog;

    private UsbManager usbManager;
    private UsbSerialPort usbPort;
    private UsbDeviceConnection usbConnection;
    private UsbDevice pendingUsbDevice;
    private boolean usbReceiverRegistered = false;

    private Socket wifiSocket;
    private InputStream wifiIn;
    private OutputStream wifiOut;
    private String connectionTransport = "";

    private SQLiteDatabase dtcDatabase;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ExecutorService liveIo = Executors.newSingleThreadExecutor();
    private final ExecutorService translationIo = Executors.newFixedThreadPool(2);
    private volatile boolean liveDataRunning = false;
    private volatile int liveSession = 0;
    private final Handler main = new Handler(Looper.getMainLooper());

    private final List<BluetoothDevice> foundDevices = new ArrayList<>();
    private final Set<String> foundAddresses = new HashSet<>();
    private ArrayAdapter<String> deviceListAdapter;
    private AlertDialog deviceDialog;
    private Runnable pendingPermissionAction;
    private boolean receiverRegistered = false;
    private String connectedName = "OBD2";
    private String connectedProtocol = "";
    private volatile boolean fastLiveProtocol = false;
    private android.content.SharedPreferences prefs;
    private volatile String preferredProtocol = "0";
    private android.content.SharedPreferences translationPrefs;
    private final Map<String, Translator> translators = new HashMap<>();

    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!ACTION_USB_PERMISSION.equals(intent.getAction())) return;
            UsbDevice device;
            if (Build.VERSION.SDK_INT >= 33) device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice.class);
            else device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
            boolean granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
            if (granted && device != null) connectUsbDevice(device);
            else jsError("USB permission was not granted.");
        }
    };

    private final BroadcastReceiver btReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device;
                if (Build.VERSION.SDK_INT >= 33) {
                    device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
                } else {
                    device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                }
                if (device != null) addDevice(device);
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                jsStatus("Scan finished. Select your OBD2 adapter.", false);
            }
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        btAdapter = manager != null ? manager.getAdapter() : null;
        usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
        prefs = getSharedPreferences("cardoc_obd", MODE_PRIVATE);
        translationPrefs = getSharedPreferences("cardoc_translations", MODE_PRIVATE);
        preferredProtocol = prefs.getString("preferred_protocol", "0");

        webView = new WebView(this);
        setContentView(webView);
        webView.setBackgroundColor(0xFF08111F);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowFileAccessFromFileURLs(true);
        webView.getSettings().setAllowUniversalAccessFromFileURLs(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new ObdBridge(), "AndroidOBD");
        webView.loadUrl("file:///android_asset/index.html");

        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(btReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(btReceiver, filter);
        }
        receiverRegistered = true;

        IntentFilter usbFilter = new IntentFilter(ACTION_USB_PERMISSION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(usbReceiver, usbFilter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(usbReceiver, usbFilter);
        usbReceiverRegistered = true;
    }

    public class ObdBridge {
        @JavascriptInterface public void scanBluetooth() {
            main.post(() -> ensureBluetoothReady(MainActivity.this::showDevicePicker));
        }

        @JavascriptInterface public void scanBluetoothBle() {
            main.post(() -> ensureBluetoothReady(MainActivity.this::showBleDevicePicker));
        }

        @JavascriptInterface public void connectUsb() {
            main.post(MainActivity.this::showUsbPicker);
        }

        @JavascriptInterface public void quickScan() {
            quickScanNative("");
        }

        @JavascriptInterface public void allSystemsScan(String manufacturer) {
            quickScanNative(manufacturer == null ? "" : manufacturer);
        }

        @JavascriptInterface public void batteryTest() {
            batteryTestNative();
        }

        @JavascriptInterface public void connectWifi() {
            connectWifiNative(null, 0);
        }

        @JavascriptInterface public void connectWifiManual(String host, int port) {
            connectWifiNative(host, port);
        }

        @JavascriptInterface public boolean isConnected() {
            return isSocketConnected();
        }

        @JavascriptInterface public String getConnectedDeviceName() {
            return connectedName == null || connectedName.trim().isEmpty() ? "OBD2" : connectedName;
        }

        @JavascriptInterface public String getConnectedProtocol() {
            return connectedProtocol == null ? "" : connectedProtocol;
        }

        @JavascriptInterface public String getConnectedTransport() {
            return connectionTransport == null ? "" : connectionTransport;
        }

        @JavascriptInterface public String lookupDtc(String code, String manufacturer) {
            return lookupDtcJson(code, manufacturer);
        }

        @JavascriptInterface public int getDtcDefinitionCount() {
            return getDtcDefinitionCountNative();
        }

        @JavascriptInterface public void readCodes() {
            readCodesNative();
        }

        @JavascriptInterface public void clearCodes() {
            clearCodesNative();
        }

        @JavascriptInterface public void readPendingPermanent() {
            readPendingPermanentNative();
        }

        @JavascriptInterface public void readFreezeFrame() {
            readFreezeFrameNative();
        }

        @JavascriptInterface public void readReadiness() {
            readReadinessNative();
        }

        @JavascriptInterface public void readVin() {
            readVinNative();
        }

        @JavascriptInterface public void readMode06() {
            readMode06Native();
        }

        @JavascriptInterface public void readCustomPid(String command) {
            readCustomPidNative(command);
        }

        @JavascriptInterface public void adapterTest() {
            adapterTestNative();
        }

        @JavascriptInterface public void reconnectLast() {
            main.post(MainActivity.this::reconnectLastNative);
        }

        @JavascriptInterface public void setAutoReconnect(boolean enabled) {
            if (prefs != null) prefs.edit().putBoolean("auto_reconnect", enabled).apply();
        }

        @JavascriptInterface public boolean isAutoReconnectEnabled() {
            return prefs == null || prefs.getBoolean("auto_reconnect", true);
        }

        @JavascriptInterface public void setPreferredProtocol(String id) {
            String v = id == null ? "0" : id.trim();
            if (!v.matches("[0-9]")) v = "0";
            preferredProtocol = v;
            if (prefs != null) prefs.edit().putString("preferred_protocol", v).apply();
        }

        @JavascriptInterface public String getPreferredProtocol() {
            return preferredProtocol == null ? "0" : preferredProtocol;
        }

        @JavascriptInterface public void shareText(String title, String text) {
            final String safeTitle = title == null || title.trim().isEmpty() ? "CarDoc report" : title;
            final String safeText = text == null ? "" : text;
            main.post(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_SUBJECT, safeTitle);
                    send.putExtra(Intent.EXTRA_TEXT, safeText);
                    startActivity(Intent.createChooser(send, safeTitle));
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface public void translateText(String requestId, String text, String targetLanguage) {
            translateTextNative(requestId, text, targetLanguage);
        }

        @JavascriptInterface public void disconnect() {
            disconnectNative(true);
        }

        @JavascriptInterface public void exitApp() {
            liveSession++;
            liveDataRunning = false;
            main.post(() -> {
                stopDiscovery();
                disconnectSocketOnly();
                finishAndRemoveTask();
            });
        }

        @JavascriptInterface public void startLiveData() {
            startLiveDataNative();
        }

        @JavascriptInterface public void stopLiveData() {
            liveSession++;
            liveDataRunning = false;
        }

        @JavascriptInterface public String getAssetText(String name) {
            if (!"codes.json".equals(name) && !"symptoms.json".equals(name) && !"parts-map.json".equals(name)) return "";
            try (InputStream in = getAssets().open(name);
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) != -1) {
                    out.write(buffer, 0, n);
                }
                return out.toString(StandardCharsets.UTF_8.name());
            } catch (Exception e) {
                return "";
            }
        }
    }

    private void translateTextNative(String requestId, String text, String targetLanguage) {
        final String id = requestId == null ? "" : requestId;
        final String src = text == null ? "" : text.trim();
        final String target = targetLanguage == null ? "en" : targetLanguage.trim().toLowerCase(Locale.US);
        if (src.isEmpty() || target.isEmpty() || "en".equals(target)) {
            jsTranslationResult(id, src, true);
            return;
        }
        String cacheKey = target + "_" + Integer.toHexString(src.hashCode()) + "_" + src.length();
        try {
            String cached = translationPrefs == null ? "" : translationPrefs.getString(cacheKey, "");
            if (cached != null && !cached.isEmpty()) {
                jsTranslationResult(id, cached, true);
                return;
            }
        } catch (Exception ignored) {}

        String targetCode = TranslateLanguage.fromLanguageTag(target);
        if (targetCode != null) {
            main.post(() -> {
                try {
                    Translator translator = translators.get(target);
                    if (translator == null) {
                        TranslatorOptions options = new TranslatorOptions.Builder()
                                .setSourceLanguage(TranslateLanguage.ENGLISH)
                                .setTargetLanguage(targetCode)
                                .build();
                        translator = Translation.getClient(options);
                        translators.put(target, translator);
                    }
                    final Translator trClient = translator;
                    DownloadConditions conditions = new DownloadConditions.Builder().build();
                    trClient.downloadModelIfNeeded(conditions)
                            .addOnSuccessListener(v -> trClient.translate(src)
                                    .addOnSuccessListener(translated -> {
                                        cacheTranslation(cacheKey, translated);
                                        jsTranslationResult(id, translated, true);
                                    })
                                    .addOnFailureListener(e -> translateTextOnlineFallback(id, src, target, cacheKey)))
                            .addOnFailureListener(e -> translateTextOnlineFallback(id, src, target, cacheKey));
                } catch (Exception e) {
                    translateTextOnlineFallback(id, src, target, cacheKey);
                }
            });
        } else {
            translateTextOnlineFallback(id, src, target, cacheKey);
        }
    }

    private void translateTextOnlineFallback(String requestId, String text, String target, String cacheKey) {
        translationIo.execute(() -> {
            String translated = "";
            boolean ok = false;
            HttpURLConnection conn = null;
            try {
                String q = URLEncoder.encode(text, "UTF-8");
                String pair = URLEncoder.encode("en|" + target, "UTF-8");
                URL url = new URL("https://api.mymemory.translated.net/get?q=" + q + "&langpair=" + pair);
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(7000);
                conn.setReadTimeout(9000);
                conn.setRequestProperty("User-Agent", "CarDoc/1.26");
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    JSONObject obj = new JSONObject(sb.toString());
                    JSONObject data = obj.optJSONObject("responseData");
                    translated = data == null ? "" : data.optString("translatedText", "");
                    ok = translated != null && !translated.trim().isEmpty();
                }
            } catch (Exception ignored) {
            } finally {
                if (conn != null) conn.disconnect();
            }
            if (ok) cacheTranslation(cacheKey, translated);
            jsTranslationResult(requestId, ok ? translated : text, ok);
        });
    }

    private void cacheTranslation(String key, String value) {
        try {
            if (translationPrefs != null && key != null && value != null && !value.isEmpty()) {
                translationPrefs.edit().putString(key, value).apply();
            }
        } catch (Exception ignored) {}
    }

    private void jsTranslationResult(String requestId, String text, boolean ok) {
        final String id = requestId == null ? "" : requestId;
        final String out = text == null ? "" : text;
        main.post(() -> {
            if (webView == null) return;
            String js = "if(window.nativeTranslationResult){window.nativeTranslationResult(" + JSONObject.quote(id) + "," + JSONObject.quote(out) + "," + ok + ");}";
            webView.evaluateJavascript(js, null);
        });
    }

    private void ensureBluetoothReady(Runnable action) {
        if (btAdapter == null) {
            jsError("Bluetooth is not available on this device.");
            return;
        }
        if (!hasBtPermissions()) {
            pendingPermissionAction = action;
            requestBtPermissions();
            return;
        }
        if (!btAdapter.isEnabled()) {
            pendingPermissionAction = action;
            try {
                startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_ENABLE_BT);
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            }
            return;
        }
        action.run();
    }

    private boolean hasBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT_PERMS);
        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_BT_PERMS);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT_PERMS) {
            if (hasBtPermissions()) {
                Runnable r = pendingPermissionAction;
                pendingPermissionAction = null;
                if (r != null) ensureBluetoothReady(r);
            } else {
                jsError("Bluetooth permission is required to find the OBD2 adapter.");
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_ENABLE_BT) {
            Runnable r = pendingPermissionAction;
            pendingPermissionAction = null;
            if (btAdapter != null && btAdapter.isEnabled() && r != null) r.run();
            else jsError("Bluetooth is turned off.");
        }
    }

    private void showDevicePicker() {
        foundDevices.clear();
        foundAddresses.clear();

        ListView listView = new ListView(this);
        deviceListAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_2, android.R.id.text1, new ArrayList<>());
        listView.setAdapter(deviceListAdapter);

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("Select OBD2 Bluetooth device")
                .setView(listView)
                .setNegativeButton("Cancel", (d, w) -> stopDiscovery());
        deviceDialog = builder.create();
        deviceDialog.setOnDismissListener(d -> stopDiscovery());
        deviceDialog.show();

        // Paired devices appear immediately.
        try {
            Set<BluetoothDevice> bonded = btAdapter.getBondedDevices();
            if (bonded != null) {
                List<BluetoothDevice> sorted = new ArrayList<>(bonded);
                sortObdFirst(sorted);
                for (BluetoothDevice d : sorted) addDevice(d);
            }
        } catch (SecurityException ignored) {}

        listView.setOnItemClickListener((parent, view, position, id) -> {
            if (position < 0 || position >= foundDevices.size()) return;
            BluetoothDevice selected = foundDevices.get(position);
            stopDiscovery();
            if (deviceDialog != null) deviceDialog.dismiss();
            connectClassic(selected);
        });

        jsStatus("Searching Bluetooth devices…", false);
        try {
            if (btAdapter.isDiscovering()) btAdapter.cancelDiscovery();
            btAdapter.startDiscovery();
        } catch (SecurityException e) {
            jsError("Bluetooth scan permission is missing.");
        }
    }

    private void addDevice(BluetoothDevice device) {
        main.post(() -> {
            try {
                String address = device.getAddress();
                if (address == null || foundAddresses.contains(address)) return;
                String name = device.getName();
                if (name == null || name.trim().isEmpty()) name = "Unknown Bluetooth device";

                // Put OBD-like names near the top while still showing all Classic devices.
                int insertAt = looksLikeObd(name) ? firstNonObdIndex() : foundDevices.size();
                foundAddresses.add(address);
                foundDevices.add(insertAt, device);
                deviceListAdapter.insert(name + "\n" + address, insertAt);
                deviceListAdapter.notifyDataSetChanged();
            } catch (SecurityException ignored) {}
        });
    }

    private int firstNonObdIndex() {
        for (int i = 0; i < foundDevices.size(); i++) {
            try {
                String n = foundDevices.get(i).getName();
                if (!looksLikeObd(n)) return i;
            } catch (SecurityException e) { return i; }
        }
        return foundDevices.size();
    }

    private boolean looksLikeObd(String name) {
        if (name == null) return false;
        String n = name.toUpperCase(Locale.ROOT);
        return n.contains("OBD") || n.contains("ELM") || n.contains("V-LINK") || n.contains("VLINK")
                || n.contains("VGATE") || n.contains("ICAR") || n.contains("VIECAR") || n.contains("VEEPEAK")
                || n.contains("KONNWEI") || n.contains("CARISTA");
    }

    private void sortObdFirst(List<BluetoothDevice> list) {
        Collections.sort(list, (a,b) -> {
            try {
                boolean ao = looksLikeObd(a.getName());
                boolean bo = looksLikeObd(b.getName());
                if (ao == bo) return 0;
                return ao ? -1 : 1;
            } catch (SecurityException e) { return 0; }
        });
    }

    private void stopDiscovery() {
        try {
            if (btAdapter != null && btAdapter.isDiscovering()) btAdapter.cancelDiscovery();
        } catch (SecurityException ignored) {}
    }

    private void showBleDevicePicker() {
        if (btAdapter == null) { jsError("Bluetooth is not available on this device."); return; }
        bleScanner = btAdapter.getBluetoothLeScanner();
        if (bleScanner == null) { jsError("Bluetooth LE scanning is not available."); return; }
        foundBleDevices.clear(); foundBleAddresses.clear();
        ListView listView = new ListView(this);
        bleListAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_2, android.R.id.text1, new ArrayList<>());
        listView.setAdapter(bleListAdapter);
        bleDialog = new AlertDialog.Builder(this).setTitle("Select BLE OBD2 device").setView(listView)
                .setNegativeButton("Cancel", (d,w) -> stopBleScan()).create();
        bleDialog.setOnDismissListener(d -> stopBleScan()); bleDialog.show();
        listView.setOnItemClickListener((parent, view, position, id) -> {
            if (position < 0 || position >= foundBleDevices.size()) return;
            BluetoothDevice selected = foundBleDevices.get(position);
            stopBleScan(); if (bleDialog != null) bleDialog.dismiss(); connectBle(selected);
        });
        bleScanCallback = new ScanCallback() {
            @Override public void onScanResult(int callbackType, ScanResult result) { if (result != null) addBleDevice(result.getDevice()); }
            @Override public void onBatchScanResults(List<ScanResult> results) { if (results != null) for (ScanResult r: results) if (r != null) addBleDevice(r.getDevice()); }
            @Override public void onScanFailed(int errorCode) { jsError("Bluetooth LE scan failed ("+errorCode+")."); }
        };
        jsStatus("Searching Bluetooth LE OBD2 adapters…", false);
        try { bleScanner.startScan(bleScanCallback); main.postDelayed(() -> { stopBleScan(); jsStatus("BLE scan finished. Select your OBD2 adapter.", false); }, 9000); }
        catch (SecurityException e) { jsError("Bluetooth scan permission is missing."); }
    }

    private void addBleDevice(BluetoothDevice device) {
        main.post(() -> {
            try {
                if (device == null) return; String address=device.getAddress(); if (address==null || foundBleAddresses.contains(address)) return;
                String name=device.getName(); if (name==null || name.trim().isEmpty()) name="Unknown BLE device";
                int insert=looksLikeObd(name)?0:foundBleDevices.size();
                foundBleAddresses.add(address); foundBleDevices.add(insert, device); bleListAdapter.insert(name+"\n"+address, insert); bleListAdapter.notifyDataSetChanged();
            } catch (SecurityException ignored) {}
        });
    }

    private void stopBleScan() {
        try { if (bleScanner != null && bleScanCallback != null) bleScanner.stopScan(bleScanCallback); } catch (Exception ignored) {}
        bleScanCallback = null;
    }

    private final BluetoothGattCallback bleGattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                try { gatt.requestMtu(247); } catch (Exception ignored) {}
                try { gatt.discoverServices(); } catch (SecurityException ignored) {}
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                bleReady=false; if (bleGatt==gatt) { try { gatt.close(); } catch(Exception ignored){} bleGatt=null; }
                if ("BLE".equals(connectionTransport)) { connectionTransport=""; jsCall("nativeObdDisconnected()"); }
            }
        }
        @Override public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS || !selectBleCharacteristics(gatt)) { jsError("Connected, but no compatible ELM327 BLE UART service was found."); try{gatt.disconnect();}catch(Exception ignored){} return; }
            enableBleNotifications(gatt);
            bleGatt=gatt; bleReady=true; connectionTransport="BLE";
            try { connectedName=gatt.getDevice().getName(); } catch(SecurityException ignored) { connectedName="BLE OBD2"; }
            if (connectedName==null || connectedName.trim().isEmpty()) connectedName="BLE OBD2";
            io.execute(() -> { try { Thread.sleep(250); initializeElmSession(); saveLastBle(gatt.getDevice()); } catch(Exception e){ jsError("BLE adapter connected, but it did not respond as a compatible ELM327 device."); disconnectSocketOnly(); } });
        }
        @Override public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            byte[] value=characteristic.getValue(); if(value==null||value.length==0)return;
            synchronized(bleBufferLock){ bleBuffer.append(new String(value, StandardCharsets.US_ASCII)); bleBufferLock.notifyAll(); }
        }
        @Override public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            synchronized(bleWriteLock){ bleWriteOk=status==BluetoothGatt.GATT_SUCCESS; bleWriteDone=true; bleWriteLock.notifyAll(); }
        }
    };

    private boolean selectBleCharacteristics(BluetoothGatt gatt) {
        bleWriteChar=null; bleNotifyChar=null;
        BluetoothGattService nus=gatt.getService(NUS_SERVICE_UUID);
        if(nus!=null){ bleWriteChar=nus.getCharacteristic(NUS_WRITE_UUID); bleNotifyChar=nus.getCharacteristic(NUS_NOTIFY_UUID); if(bleWriteChar!=null&&bleNotifyChar!=null)return true; }
        BluetoothGattService hm=gatt.getService(HM10_SERVICE_UUID);
        if(hm!=null){ BluetoothGattCharacteristic c=hm.getCharacteristic(HM10_CHAR_UUID); if(c!=null){bleWriteChar=c;bleNotifyChar=c;return true;} }
        BluetoothGattService fff=gatt.getService(FFF0_SERVICE_UUID);
        if(fff!=null){ BluetoothGattCharacteristic c1=fff.getCharacteristic(FFF1_CHAR_UUID), c2=fff.getCharacteristic(FFF2_CHAR_UUID); if(c2!=null&&c1!=null){bleWriteChar=c2;bleNotifyChar=c1;return true;} if(c1!=null){bleWriteChar=c1;bleNotifyChar=c1;return true;} }
        for(BluetoothGattService service:gatt.getServices()){
            BluetoothGattCharacteristic write=null, notify=null;
            for(BluetoothGattCharacteristic c:service.getCharacteristics()){
                int p=c.getProperties(); if(write==null && (p&(BluetoothGattCharacteristic.PROPERTY_WRITE|BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE))!=0)write=c;
                if(notify==null && (p&(BluetoothGattCharacteristic.PROPERTY_NOTIFY|BluetoothGattCharacteristic.PROPERTY_INDICATE))!=0)notify=c;
            }
            if(write!=null&&notify!=null){bleWriteChar=write;bleNotifyChar=notify;return true;}
        }
        return false;
    }

    private void enableBleNotifications(BluetoothGatt gatt){
        try{ gatt.setCharacteristicNotification(bleNotifyChar,true); BluetoothGattDescriptor d=bleNotifyChar.getDescriptor(CCCD_UUID); if(d!=null){ d.setValue((bleNotifyChar.getProperties()&BluetoothGattCharacteristic.PROPERTY_INDICATE)!=0?BluetoothGattDescriptor.ENABLE_INDICATION_VALUE:BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE); gatt.writeDescriptor(d);} }catch(Exception ignored){}
    }

    private void connectBle(BluetoothDevice device){
        jsStatus("Connecting to Bluetooth LE OBD2…", false); disconnectSocketOnly();
        try { bleGatt=device.connectGatt(this,false,bleGattCallback,BluetoothDevice.TRANSPORT_LE); }
        catch(Exception e){ jsError("Could not connect to this Bluetooth LE device."); }
    }

    private String sendBleElm(String command,long timeoutMs)throws Exception{
        BluetoothGatt g=bleGatt; BluetoothGattCharacteristic c=bleWriteChar; if(g==null||c==null||!bleReady)throw new IllegalStateException("Not connected");
        synchronized(bleBufferLock){bleBuffer.setLength(0);} byte[] all=(command+"\r").getBytes(StandardCharsets.US_ASCII);
        int chunkSize=20;
        for(int off=0;off<all.length;off+=chunkSize){ int len=Math.min(chunkSize,all.length-off); byte[] chunk=new byte[len]; System.arraycopy(all,off,chunk,0,len);
            synchronized(bleWriteLock){ bleWriteDone=false; bleWriteOk=false; c.setValue(chunk); int props=c.getProperties(); c.setWriteType((props&BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)!=0?BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE:BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT); boolean started=g.writeCharacteristic(c); if(!started)throw new Exception("BLE write failed"); if(c.getWriteType()==BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT){ long end=System.currentTimeMillis()+1200; while(!bleWriteDone&&System.currentTimeMillis()<end)bleWriteLock.wait(80); if(bleWriteDone&&!bleWriteOk)throw new Exception("BLE write failed"); } }
            Thread.sleep(18);
        }
        long end=System.currentTimeMillis()+timeoutMs; String out="";
        synchronized(bleBufferLock){ while(System.currentTimeMillis()<end){ out=bleBuffer.toString(); if(out.contains(">"))break; bleBufferLock.wait(Math.min(100,Math.max(1,end-System.currentTimeMillis()))); } }
        if(out.isEmpty())throw new Exception("OBD timeout"); return out;
    }

    private void saveLastBle(BluetoothDevice device){ if(prefs==null||device==null)return; try{prefs.edit().putString("last_transport","BLE").putString("last_ble_address",device.getAddress()).apply();}catch(SecurityException ignored){} }

    private void showUsbPicker(){
        if(usbManager==null){jsError("USB host is not available on this device.");return;}
        List<UsbSerialDriver> drivers=UsbSerialProber.getDefaultProber().findAllDrivers(usbManager);
        if(drivers==null||drivers.isEmpty()){jsError("No compatible USB OBD2 serial adapter was found. Connect it through USB OTG first.");return;}
        String[] names=new String[drivers.size()]; for(int i=0;i<drivers.size();i++){UsbDevice d=drivers.get(i).getDevice();names[i]=(d.getProductName()!=null?d.getProductName():"USB serial device")+" • "+Integer.toHexString(d.getVendorId())+":"+Integer.toHexString(d.getProductId());}
        new AlertDialog.Builder(this).setTitle("Select USB OBD2 adapter").setItems(names,(dlg,which)->requestUsbPermissionOrConnect(drivers.get(which).getDevice())).setNegativeButton("Cancel",null).show();
    }

    private void requestUsbPermissionOrConnect(UsbDevice device){
        if(device==null||usbManager==null)return; if(usbManager.hasPermission(device)){connectUsbDevice(device);return;}
        pendingUsbDevice=device; Intent intent=new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName()); PendingIntent pi=PendingIntent.getBroadcast(this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); usbManager.requestPermission(device,pi);
    }

    private void connectUsbDevice(UsbDevice device){
        jsStatus("Connecting to USB OBD2…",false); io.execute(()->{ disconnectSocketOnly();
            try{ UsbSerialDriver chosen=null; for(UsbSerialDriver d:UsbSerialProber.getDefaultProber().findAllDrivers(usbManager))if(d.getDevice().getDeviceId()==device.getDeviceId()){chosen=d;break;} if(chosen==null)throw new Exception("No serial driver");
                usbConnection=usbManager.openDevice(device); if(usbConnection==null)throw new Exception("USB permission missing"); usbPort=chosen.getPorts().get(0); usbPort.open(usbConnection);
                int[] baudRates={38400,115200,9600,57600}; boolean ok=false; String ident="";
                for(int baud:baudRates){ try{usbPort.setParameters(baud,8,UsbSerialPort.STOPBITS_1,UsbSerialPort.PARITY_NONE); try{usbPort.setDTR(true);}catch(Exception ignored){} try{usbPort.setRTS(true);}catch(Exception ignored){} connectionTransport="USB"; connectedName=(device.getProductName()!=null?device.getProductName():"USB OBD2")+" • "+baud; ident=cleanElmText(sendElm("ATI",2200)); if(!ident.isEmpty()&&!ident.toUpperCase(Locale.ROOT).contains("ERROR")){ok=true;break;} }catch(Exception ignored){} }
                if(!ok)throw new Exception("NOT_ELM"); initializeElmSession(); if(prefs!=null)prefs.edit().putString("last_transport","USB").apply();
            }catch(Exception e){jsError("USB adapter was found, but CarDoc could not communicate with it as an ELM327 serial device.");disconnectSocketOnly();}
        });
    }

    private String sendUsbElm(String command,long timeoutMs)throws Exception{
        UsbSerialPort p=usbPort; if(p==null||!p.isOpen())throw new IllegalStateException("Not connected"); byte[] junk=new byte[512]; try{while(p.read(junk,40)>0){}}catch(Exception ignored){}
        p.write((command+"\r").getBytes(StandardCharsets.US_ASCII),1200); StringBuilder out=new StringBuilder(); long end=System.currentTimeMillis()+timeoutMs; byte[] buf=new byte[512];
        while(System.currentTimeMillis()<end){int n;try{n=p.read(buf,(int)Math.min(180,Math.max(20,end-System.currentTimeMillis())));}catch(Exception e){n=0;}if(n>0){out.append(new String(buf,0,n,StandardCharsets.US_ASCII));if(out.indexOf(">")>=0)break;}}
        if(out.length()==0)throw new Exception("OBD timeout");return out.toString();
    }

    private void connectClassic(BluetoothDevice device) {
        jsStatus("Connecting to Bluetooth OBD2…", false);
        io.execute(() -> {
            disconnectSocketOnly();
            stopDiscovery();
            BluetoothSocket socket = null;

            try {
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                socket.connect();
            } catch (Exception e) {
                closeQuietly(socket);
                try {
                    socket = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
                    socket.connect();
                } catch (Exception e2) {
                    closeQuietly(socket);
                    socket = null;
                }
            }

            if (socket == null || !socket.isConnected()) {
                jsError("Could not connect to this Bluetooth device. Pair the OBD2 adapter in Android Bluetooth settings first, then try again.");
                return;
            }

            try {
                btSocket = socket;
                btIn = socket.getInputStream();
                btOut = socket.getOutputStream();
                connectionTransport = "Bluetooth";
                try { connectedName = device.getName(); } catch (SecurityException ignored) { connectedName = "OBD2"; }
                if (connectedName == null || connectedName.trim().isEmpty()) connectedName = "OBD2";
                initializeElmSession();
                saveLastBluetooth(device);
            } catch (Exception e) {
                if ("NO_ECU_PROTOCOL".equals(e.getMessage())) {
                    jsError("Bluetooth adapter connected, but no standard OBD-II ECU protocol responded. Check ignition and vehicle OBD-II compatibility.");
                } else {
                    jsError("Connected to Bluetooth, but the OBD2 adapter did not respond correctly as an ELM327/SPP device.");
                }
                disconnectSocketOnly();
            }
        });
    }

    private void connectWifiNative(String manualHost, int manualPort) {
        jsStatus("Connecting to Wi-Fi OBD2…", false);
        io.execute(() -> {
            disconnectSocketOnly();
            stopDiscovery();
            List<String[]> endpoints = buildWifiObdEndpoints(manualHost, manualPort);

            for (String[] endpoint : endpoints) {
                String host = endpoint[0];
                int port;
                try { port = Integer.parseInt(endpoint[1]); } catch (Exception ignored) { continue; }
                Socket socket = new Socket();
                boolean elmResponded = false;
                try {
                    jsStatus("Trying Wi-Fi OBD2 " + host + ":" + port + "…", false);
                    socket.connect(new InetSocketAddress(host, port), 2200);
                    socket.setTcpNoDelay(true);
                    wifiSocket = socket;
                    wifiIn = socket.getInputStream();
                    wifiOut = socket.getOutputStream();
                    connectionTransport = "Wi-Fi";
                    connectedName = "Wi-Fi OBD2 • " + host + ":" + port;

                    String info = cleanElmText(sendElm("ATI", 2400));
                    if (info.isEmpty() || info.toUpperCase(Locale.ROOT).contains("ERROR")) throw new Exception("NOT_ELM");
                    elmResponded = true;
                    initializeElmSession();
                    saveLastWifi(host, port);
                    return;
                } catch (Exception e) {
                    boolean noEcu = elmResponded && "NO_ECU_PROTOCOL".equals(e.getMessage());
                    try { socket.close(); } catch (Exception ignored) {}
                    wifiSocket = null; wifiIn = null; wifiOut = null;
                    connectionTransport = "";
                    connectedProtocol = "";
                    fastLiveProtocol = false;
                    if (noEcu) {
                        jsError("Wi-Fi OBD2 adapter connected, but the vehicle ECU did not answer. Keep ignition ON and check OBD-II compatibility.");
                        return;
                    }
                }
            }
            jsError("Could not find the Wi-Fi OBD2 adapter. First connect the phone to the adapter's Wi-Fi network, then try again.");
        });
    }

    private List<String[]> buildWifiObdEndpoints(String manualHost, int manualPort) {
        LinkedHashSet<String> set = new LinkedHashSet<>();
        if (manualHost != null && !manualHost.trim().isEmpty() && manualPort > 0 && manualPort <= 65535) {
            set.add(manualHost.trim() + ":" + manualPort);
        }
        String gateway = getWifiGatewayAddress();
        if (gateway != null && !gateway.isEmpty()) {
            set.add(gateway + ":35000");
            set.add(gateway + ":23");
        }
        String[] common = new String[]{
                "192.168.0.10:35000", "192.168.0.10:23", "192.168.0.123:35000",
                "192.168.4.1:35000", "192.168.4.1:23", "192.168.1.1:35000", "192.168.0.1:35000"
        };
        Collections.addAll(set, common);
        List<String[]> out = new ArrayList<>();
        for (String item : set) {
            int p = item.lastIndexOf(':');
            if (p > 0 && p < item.length() - 1) out.add(new String[]{item.substring(0, p), item.substring(p + 1)});
        }
        return out;
    }

    private String getWifiGatewayAddress() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm == null) return "";
            DhcpInfo info = wm.getDhcpInfo();
            if (info == null || info.gateway == 0) return "";
            int g = info.gateway;
            return (g & 0xff) + "." + ((g >> 8) & 0xff) + "." + ((g >> 16) & 0xff) + "." + ((g >> 24) & 0xff);
        } catch (Exception e) { return ""; }
    }

    private void initializeElmSession() throws Exception {
        sendElm("ATZ", 3200);
        sendElm("ATE0", 1400);
        sendElm("ATL0", 1400);
        sendElm("ATS0", 1400);
        sendElm("ATH0", 1400);
        sendElm("ATAT1", 1400);
        String protocol = findWorkingObdProtocol();
        if (protocol == null || protocol.isEmpty()) throw new Exception("NO_ECU_PROTOCOL");
        connectedProtocol = protocol;
        fastLiveProtocol = protocol.toUpperCase(Locale.ROOT).contains("CAN");
        jsCall("nativeObdConnected(" + JSONObject.quote(connectedName) + ")");
        jsCall("nativeObdProtocol(" + JSONObject.quote(protocol) + ")");
        readCodesNative();
        readVinNative();
    }

    private void readCodesNative() {
        // Do not let continuous live PID polling compete with Mode 03.
        liveDataRunning = false;
        io.execute(() -> {
            if (!isSocketConnected()) {
                jsError("OBD2 is not connected.");
                return;
            }
            try {
                Thread.sleep(180);
                jsStatus("Reading stored engine trouble codes…", true);
                String raw = sendElm("03", 10000);
                if (isElmConnectionFailure(raw)) {
                    jsError("Adapter is connected, but the vehicle ECU did not answer. Keep ignition ON and try again.");
                    return;
                }
                List<String> codes = decodeDtcs(raw);
                JSONArray arr = new JSONArray();
                for (String code : codes) arr.put(code);
                jsCall("nativeObdCodes(" + arr.toString() + ")");
            } catch (Exception e) {
                jsError("Could not read OBD2 codes. Keep ignition ON and try again.");
            }
        });
    }

    private void clearCodesNative() {
        // Mode 04 should have the link to itself; pause live data first.
        liveDataRunning = false;
        io.execute(() -> {
            if (!isSocketConnected()) {
                jsError("OBD2 is not connected.");
                return;
            }
            try {
                Thread.sleep(180);
                jsStatus("Clearing stored engine/emissions codes…", true);
                String clearRaw = sendElm("04", 10000);
                if (isElmConnectionFailure(clearRaw) || clearRaw.toUpperCase(Locale.ROOT).contains("?")) {
                    jsError("The vehicle ECU did not accept the clear command.");
                    return;
                }

                Thread.sleep(1600);
                String raw = sendElm("03", 10000);
                if (isElmConnectionFailure(raw)) {
                    jsError("Codes were sent a clear command, but the ECU could not be re-read.");
                    return;
                }

                List<String> codes = decodeDtcs(raw);
                JSONArray arr = new JSONArray();
                for (String code : codes) arr.put(code);
                jsCall("nativeObdCodes(" + arr.toString() + ")");
            } catch (Exception e) {
                jsError("Could not clear the codes. Keep ignition ON and try again.");
            }
        });
    }



    private void readPendingPermanentNative() {
        liveDataRunning = false;
        io.execute(() -> {
            if (!isSocketConnected()) {
                jsError("OBD2 is not connected.");
                return;
            }

            JSONArray pending = new JSONArray();
            JSONArray permanent = new JSONArray();
            boolean pendingSupported = true;
            boolean permanentSupported = true;

            try {
                String raw = sendElm("07", 8000);
                String u = raw == null ? "" : raw.toUpperCase(Locale.ROOT);
                if (u.contains("NO DATA") || u.contains("?") || u.contains("UNABLE TO CONNECT")) {
                    pendingSupported = false;
                } else {
                    for (String code : decodeDtcsFromMode(raw, "47")) pending.put(code);
                }
            } catch (Exception e) {
                pendingSupported = false;
            }

            try {
                String raw = sendElm("0A", 8000);
                String u = raw == null ? "" : raw.toUpperCase(Locale.ROOT);
                if (u.contains("NO DATA") || u.contains("?") || u.contains("UNABLE TO CONNECT")) {
                    permanentSupported = false;
                } else {
                    for (String code : decodeDtcsFromMode(raw, "4A")) permanent.put(code);
                }
            } catch (Exception e) {
                permanentSupported = false;
            }

            try {
                JSONObject out = new JSONObject();
                out.put("pending", pending);
                out.put("permanent", permanent);
                out.put("pendingSupported", pendingSupported);
                out.put("permanentSupported", permanentSupported);
                jsCall("nativeObdExtraCodes(" + out.toString() + ")");
            } catch (Exception ignored) {}
        });
    }

    private void readFreezeFrameNative() {
        liveDataRunning = false;
        io.execute(() -> {
            if (!isSocketConnected()) {
                jsError("OBD2 is not connected.");
                return;
            }

            JSONObject out = new JSONObject();
            boolean any = false;

            try {
                String raw = "";
                try { raw = sendElm("020200", 4500); } catch (Exception ignored) {}
                int[] dtcBytes = extractMode02PidBytes(raw, 0x02, 2);
                if (dtcBytes == null) {
                    try {
                        raw = sendElm("0202", 4500);
                        dtcBytes = extractMode02PidBytes(raw, 0x02, 2);
                    } catch (Exception ignored) {}
                }
                if (dtcBytes != null && dtcBytes.length >= 2) {
                    String dtc = decodeDtcPair(dtcBytes[0], dtcBytes[1]);
                    if (dtc != null && !"P0000".equals(dtc)) {
                        out.put("dtc", dtc);
                        any = true;
                    }
                }

                any |= putFreezePid(out, "load", 0x04);
                any |= putFreezePid(out, "coolant", 0x05);
                any |= putFreezePid(out, "stft1", 0x06);
                any |= putFreezePid(out, "ltft1", 0x07);
                any |= putFreezePid(out, "map", 0x0B);
                any |= putFreezePid(out, "rpm", 0x0C);
                any |= putFreezePid(out, "speed", 0x0D);
                any |= putFreezePid(out, "intakeTemp", 0x0F);
                any |= putFreezePid(out, "maf", 0x10);
                any |= putFreezePid(out, "throttle", 0x11);
            } catch (Exception ignored) {}

            try {
                out.put("available", any);
                jsCall("nativeObdFreezeFrame(" + out.toString() + ")");
            } catch (Exception ignored) {}
        });
    }

    private boolean putFreezePid(JSONObject out, String key, int pid) {
        try {
            String cmd = "02" + String.format(Locale.ROOT, "%02X", pid) + "00";
            String raw = sendElm(cmd, 2600);
            int need = (pid == 0x0C || pid == 0x10) ? 2 : 1;
            int[] b = extractMode02PidBytes(raw, pid, need);
            if (b == null || b.length < need) return false;

            int a = b[0];
            int bb = need > 1 ? b[1] : 0;
            Double value = null;

            switch (pid) {
                case 0x04: value = a * 100.0 / 255.0; break;
                case 0x05: value = (double)a - 40.0; break;
                case 0x06:
                case 0x07: value = (a - 128.0) * 100.0 / 128.0; break;
                case 0x0B: value = (double)a; break;
                case 0x0C: value = ((a * 256.0) + bb) / 4.0; break;
                case 0x0D: value = (double)a; break;
                case 0x0F: value = (double)a - 40.0; break;
                case 0x10: value = ((a * 256.0) + bb) / 100.0; break;
                case 0x11: value = a * 100.0 / 255.0; break;
            }

            if (value != null) {
                out.put(key, Math.round(value * 10.0) / 10.0);
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private int[] extractMode02PidBytes(String raw, int pid, int count) {
        if (raw == null) return null;
        String compact = raw.toUpperCase(Locale.ROOT).replaceAll("[^0-9A-F]", "");
        String marker = "42" + String.format(Locale.ROOT, "%02X", pid);
        int pos = compact.indexOf(marker);
        if (pos < 0) return null;
        int start = pos + marker.length();

        if (compact.length() >= start + (count + 1) * 2) {
            String maybeFrame = compact.substring(start, start + 2);
            if ("00".equals(maybeFrame) || "01".equals(maybeFrame) || "02".equals(maybeFrame)) {
                start += 2;
            }
        }

        if (compact.length() < start + count * 2) return null;
        int[] out = new int[count];
        try {
            for (int i = 0; i < count; i++) {
                out[i] = Integer.parseInt(compact.substring(start + i * 2, start + i * 2 + 2), 16);
            }
            return out;
        } catch (Exception e) {
            return null;
        }
    }

    private void readReadinessNative() {
        liveDataRunning = false;
        io.execute(() -> {
            if (!isSocketConnected()) {
                jsError("OBD2 is not connected.");
                return;
            }

            JSONObject out = new JSONObject();
            try {
                String raw = sendElm("0101", 4500);
                int[] b = extractPidBytes(raw, 0x01, 4);
                if (b == null || b.length < 4) {
                    out.put("available", false);
                    jsCall("nativeObdReadiness(" + out.toString() + ")");
                    return;
                }

                int a = b[0], bb = b[1], c = b[2], d = b[3];
                boolean compression = (bb & 0x08) != 0;
                out.put("available", true);
                out.put("mil", (a & 0x80) != 0);
                out.put("dtcCount", a & 0x7F);
                out.put("engineType", compression ? "compression" : "spark");

                JSONArray monitors = new JSONArray();
                addReadinessMonitor(monitors, "misfire", (bb & 0x01) != 0, (bb & 0x10) == 0);
                addReadinessMonitor(monitors, "fuelSystem", (bb & 0x02) != 0, (bb & 0x20) == 0);
                addReadinessMonitor(monitors, "components", (bb & 0x04) != 0, (bb & 0x40) == 0);

                if (!compression) {
                    addReadinessMonitor(monitors, "catalyst", (c & 0x01) != 0, (d & 0x01) == 0);
                    addReadinessMonitor(monitors, "heatedCatalyst", (c & 0x02) != 0, (d & 0x02) == 0);
                    addReadinessMonitor(monitors, "evap", (c & 0x04) != 0, (d & 0x04) == 0);
                    addReadinessMonitor(monitors, "secondaryAir", (c & 0x08) != 0, (d & 0x08) == 0);
                    addReadinessMonitor(monitors, "acRefrigerant", (c & 0x10) != 0, (d & 0x10) == 0);
                    addReadinessMonitor(monitors, "o2Sensor", (c & 0x20) != 0, (d & 0x20) == 0);
                    addReadinessMonitor(monitors, "o2Heater", (c & 0x40) != 0, (d & 0x40) == 0);
                    addReadinessMonitor(monitors, "egrVvt", (c & 0x80) != 0, (d & 0x80) == 0);
                } else {
                    addReadinessMonitor(monitors, "nmhcCatalyst", (c & 0x01) != 0, (d & 0x01) == 0);
                    addReadinessMonitor(monitors, "noxScr", (c & 0x02) != 0, (d & 0x02) == 0);
                    addReadinessMonitor(monitors, "boostPressure", (c & 0x08) != 0, (d & 0x08) == 0);
                    addReadinessMonitor(monitors, "exhaustGasSensor", (c & 0x20) != 0, (d & 0x20) == 0);
                    addReadinessMonitor(monitors, "pmFilter", (c & 0x40) != 0, (d & 0x40) == 0);
                    addReadinessMonitor(monitors, "egrVvt", (c & 0x80) != 0, (d & 0x80) == 0);
                }

                out.put("monitors", monitors);
            } catch (Exception e) {
                try { out.put("available", false); } catch (Exception ignored) {}
            }
            jsCall("nativeObdReadiness(" + out.toString() + ")");
        });
    }

    private void addReadinessMonitor(JSONArray arr, String id, boolean supported, boolean complete) {
        try {
            JSONObject m = new JSONObject();
            m.put("id", id);
            m.put("supported", supported);
            m.put("complete", supported && complete);
            arr.put(m);
        } catch (Exception ignored) {}
    }

    private void readVinNative() {
        liveDataRunning = false;
        io.execute(() -> {
            if (!isSocketConnected()) return;
            String vin = "";
            try {
                String raw = sendElm("0902", 9000);
                vin = decodeVin(raw);
            } catch (Exception ignored) {}
            jsCall("nativeObdVin(" + JSONObject.quote(vin) + ")");
        });
    }

    private String decodeVin(String raw) {
        if (raw == null) return "";
        String upper = raw.toUpperCase(Locale.ROOT)
                .replace("SEARCHING...", " ")
                .replace("SEARCHING", " ")
                .replace("NO DATA", " ")
                .replace(">", " ");
        String[] parts = upper.split("[^0-9A-F]+");
        List<String> bytes = new ArrayList<>();
        for (String p : parts) if (p.matches("[0-9A-F]{2}")) bytes.add(p);

        StringBuilder chars = new StringBuilder();
        for (int i = 0; i + 2 < bytes.size(); i++) {
            if (!"49".equals(bytes.get(i)) || !"02".equals(bytes.get(i + 1))) continue;
            int j = i + 2;
            if (j < bytes.size()) j++;
            while (j < bytes.size()) {
                if (j + 1 < bytes.size() && "49".equals(bytes.get(j)) && "02".equals(bytes.get(j + 1))) break;
                try {
                    int v = Integer.parseInt(bytes.get(j), 16);
                    char ch = (char)v;
                    if ((ch >= '0' && ch <= '9') || (ch >= 'A' && ch <= 'Z')) chars.append(ch);
                } catch (Exception ignored) {}
                j++;
            }
        }

        String s = chars.toString();
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("[A-HJ-NPR-Z0-9]{17}").matcher(s);
        return m.find() ? m.group() : "";
    }

    private void readMode06Native() {
        liveDataRunning = false;
        io.execute(() -> {
            JSONObject out = new JSONObject();
            JSONArray blocks = new JSONArray();
            boolean available = false;
            try {
                if (!isSocketConnected()) throw new IllegalStateException("Not connected");
                String[] commands = {"0600","0620","0640","0660","0680","06A0","06C0","06E0"};
                for (String cmd : commands) {
                    try {
                        String raw = sendElm(cmd, 5000);
                        String upper = raw == null ? "" : raw.toUpperCase(Locale.ROOT);
                        if (upper.contains("NO DATA") || upper.contains("UNABLE TO CONNECT") || upper.contains("?")) continue;
                        String clean = cleanElmText(raw);
                        if (clean.isEmpty()) continue;
                        JSONObject row = new JSONObject();
                        row.put("command", cmd);
                        row.put("response", clean);
                        blocks.put(row);
                        available = true;
                    } catch (Exception ignored) {}
                }
            } catch (Exception ignored) {}
            try {
                out.put("available", available);
                out.put("blocks", blocks);
                jsCall("nativeObdMode06(" + out.toString() + ")");
            } catch (Exception ignored) {}
        });
    }

    private boolean isSafeReadOnlyCommand(String command) {
        if (command == null) return false;
        String c = command.replaceAll("\\s+", "").toUpperCase(Locale.ROOT);
        if (!c.matches("^[0-9A-F]{4,12}$")) return false;
        if ((c.length() & 1) != 0) return false;
        String mode = c.substring(0, 2);
        return mode.equals("01") || mode.equals("02") || mode.equals("06") || mode.equals("09")
                || mode.equals("21") || mode.equals("22");
    }

    private void readCustomPidNative(String command) {
        final String cmd = command == null ? "" : command.replaceAll("\\s+", "").toUpperCase(Locale.ROOT);
        if (!isSafeReadOnlyCommand(cmd)) {
            jsCall("nativeCustomPidResult(" + JSONObject.quote(cmd) + "," + JSONObject.quote("") + ",false)");
            return;
        }
        liveDataRunning = false;
        io.execute(() -> {
            String result = "";
            boolean ok = false;
            try {
                if (isSocketConnected()) {
                    result = cleanElmText(sendElm(cmd, 6500));
                    String u = result.toUpperCase(Locale.ROOT);
                    ok = !result.isEmpty() && !u.contains("NO DATA") && !u.contains("UNABLE TO CONNECT") && !u.contains("?");
                }
            } catch (Exception ignored) {}
            jsCall("nativeCustomPidResult(" + JSONObject.quote(cmd) + "," + JSONObject.quote(result) + "," + ok + ")");
        });
    }

    private void adapterTestNative() {
        liveDataRunning = false;
        io.execute(() -> {
            JSONObject o = new JSONObject();
            boolean ok = false;
            try {
                if (isSocketConnected()) {
                    String identity = cleanElmText(sendElm("ATI", 2500));
                    String voltage = cleanElmText(sendElm("ATRV", 2500));
                    String protocol = cleanElmText(sendElm("ATDP", 2500));
                    String probe = cleanElmText(sendElm("0100", 4500));
                    o.put("identity", identity);
                    o.put("voltage", voltage);
                    o.put("protocol", protocol);
                    o.put("ecuResponse", probe);
                    o.put("transport", connectionTransport);
                    ok = !identity.isEmpty();
                }
            } catch (Exception ignored) {}
            try { o.put("ok", ok); } catch (Exception ignored) {}
            jsCall("nativeAdapterTest(" + o.toString() + ")");
        });
    }

    private void saveLastBluetooth(BluetoothDevice device) {
        if (prefs == null || device == null) return;
        try {
            prefs.edit().putString("last_transport", "Bluetooth")
                    .putString("last_bt_address", device.getAddress()).apply();
        } catch (SecurityException ignored) {}
    }

    private void saveLastWifi(String host, int port) {
        if (prefs == null) return;
        prefs.edit().putString("last_transport", "Wi-Fi")
                .putString("last_wifi_host", host == null ? "" : host)
                .putInt("last_wifi_port", port).apply();
    }

    private void reconnectLastNative() {
        if (isSocketConnected()) {
            jsCall("nativeObdConnected(" + JSONObject.quote(connectedName) + ")");
            if (connectedProtocol != null && !connectedProtocol.isEmpty()) jsCall("nativeObdProtocol(" + JSONObject.quote(connectedProtocol) + ")");
            return;
        }
        if (prefs == null) {
            jsError("No previous OBD2 connection is saved.");
            return;
        }
        String transport = prefs.getString("last_transport", "");
        if ("Bluetooth".equals(transport)) {
            String address = prefs.getString("last_bt_address", "");
            if (address == null || address.isEmpty() || btAdapter == null) {
                jsError("No previous Bluetooth OBD2 adapter is saved.");
                return;
            }
            ensureBluetoothReady(() -> {
                try { connectClassic(btAdapter.getRemoteDevice(address)); }
                catch (Exception e) { jsError("Could not reconnect to the previous Bluetooth adapter."); }
            });
            return;
        }
        if ("BLE".equals(transport)) {
            String address = prefs.getString("last_ble_address", "");
            if (address == null || address.isEmpty() || btAdapter == null) { jsError("No previous BLE OBD2 adapter is saved."); return; }
            ensureBluetoothReady(() -> { try { connectBle(btAdapter.getRemoteDevice(address)); } catch (Exception e) { jsError("Could not reconnect to the previous BLE adapter."); } });
            return;
        }
        if ("USB".equals(transport)) { main.post(this::showUsbPicker); return; }
        if ("Wi-Fi".equals(transport)) {
            String host = prefs.getString("last_wifi_host", "");
            int port = prefs.getInt("last_wifi_port", 0);
            if (host == null || host.isEmpty() || port <= 0) {
                jsError("No previous Wi-Fi OBD2 adapter is saved.");
                return;
            }
            connectWifiNative(host, port);
            return;
        }
        jsError("No previous OBD2 connection is saved yet.");
    }

    private JSONArray toJsonArray(List<String> list){ JSONArray a=new JSONArray(); if(list!=null)for(String x:list)a.put(x); return a; }

    private double parseElmVoltage(String text){ if(text==null)return Double.NaN; Matcher m=Pattern.compile("([0-9]+(?:\\.[0-9]+)?)\\s*V",Pattern.CASE_INSENSITIVE).matcher(text); if(m.find())try{return Double.parseDouble(m.group(1));}catch(Exception ignored){} return Double.NaN; }

    private void quickScanNative(String manufacturer){
        liveDataRunning=false;
        io.execute(()->{
            JSONObject out=new JSONObject();
            try{
                if(!isSocketConnected())throw new IllegalStateException("Not connected");
                jsStatus("Running CarDoc all-systems read-only scan…",true);
                out.put("transport",connectionTransport);
                out.put("protocol",connectedProtocol);
                out.put("device",connectedName);

                List<String> stored=new ArrayList<>(), pending=new ArrayList<>(), permanent=new ArrayList<>();
                try{stored=decodeDtcsFromMode(sendElm("03",6500),"43");}catch(Exception ignored){}
                try{pending=decodeDtcsFromMode(sendElm("07",4500),"47");}catch(Exception ignored){}
                try{permanent=decodeDtcsFromMode(sendElm("0A",4500),"4A");}catch(Exception ignored){}
                out.put("stored",toJsonArray(stored));
                out.put("pending",toJsonArray(pending));
                out.put("permanent",toJsonArray(permanent));

                try{
                    String r=sendElm("0101",3500);int[] b=extractPidBytes(r,0x01,4);
                    if(b!=null&&b.length>=4){
                        int A=b[0],B=b[1],C=b[2],D=b[3];
                        out.put("mil",(A&0x80)!=0);out.put("ecuDtcCount",A&0x7F);
                        int supported=0,incomplete=0;
                        int[] masks={(B&0x01),(B&0x02),(B&0x04),(C&0x01),(C&0x02),(C&0x04),(C&0x08),(C&0x10),(C&0x20),(C&0x40),(C&0x80)};
                        int[] notReady={(B&0x10),(B&0x20),(B&0x40),(D&0x01),(D&0x02),(D&0x04),(D&0x08),(D&0x10),(D&0x20),(D&0x40),(D&0x80)};
                        for(int i=0;i<masks.length;i++)if(masks[i]!=0){supported++;if(notReady[i]!=0)incomplete++;}
                        out.put("readinessSupported",supported);out.put("readinessIncomplete",incomplete);
                    }
                }catch(Exception ignored){}
                try{out.put("vin",decodeVin(sendElm("0902",6500)));}catch(Exception ignored){}
                try{out.put("voltage",parseElmVoltage(cleanElmText(sendElm("ATRV",2200))));}catch(Exception ignored){}
                try{Double rpm=queryPidValue(0x0C);if(rpm!=null)out.put("rpm",rpm);}catch(Exception ignored){}

                JSONArray modules=new JSONArray();
                List<String> engineCodes=new ArrayList<>(), transmissionCodes=new ArrayList<>();
                for(String code:stored){if(isTransmissionDtc(code))addUnique(transmissionCodes,code);else addUnique(engineCodes,code);}
                for(String code:pending){if(isTransmissionDtc(code))addUnique(transmissionCodes,code);else addUnique(engineCodes,code);}
                for(String code:permanent){if(isTransmissionDtc(code))addUnique(transmissionCodes,code);else addUnique(engineCodes,code);}
                modules.put(moduleJson("engine",true,"OBD-II",engineCodes,"standard"));

                boolean can11=isLikely11BitCan(connectedProtocol);
                if(can11){
                    jsStatus("Scanning transmission, ABS, airbag/SRS, steering and body modules (read-only)…",true);
                    JSONArray uds=scanCommonReadOnlyModules(manufacturer);
                    boolean hasTransmission=false;
                    for(int i=0;i<uds.length();i++){
                        JSONObject m=uds.optJSONObject(i);
                        if(m==null)continue;
                        if("transmission".equals(m.optString("type"))){
                            hasTransmission=m.optBoolean("detected",false);
                            JSONArray c=m.optJSONArray("codes");
                            if(c!=null)for(int j=0;j<c.length();j++)addUnique(transmissionCodes,c.optString(j));
                            m.put("codes",toJsonArray(transmissionCodes));
                        }
                        modules.put(m);
                    }
                    if(!hasTransmission && !transmissionCodes.isEmpty()) modules.put(moduleJson("transmission",true,"OBD-II",transmissionCodes,"standard"));
                    out.put("moduleScanMode","uds-can-readonly");
                }else{
                    modules.put(moduleJson("transmission",!transmissionCodes.isEmpty(),"OBD-II",transmissionCodes,"standard"));
                    modules.put(moduleJson("abs",false,"",new ArrayList<>(),"manufacturer-profile-required"));
                    modules.put(moduleJson("airbag",false,"",new ArrayList<>(),"manufacturer-profile-required"));
                    modules.put(moduleJson("steering",false,"",new ArrayList<>(),"manufacturer-profile-required"));
                    modules.put(moduleJson("bcm",false,"",new ArrayList<>(),"manufacturer-profile-required"));
                    out.put("moduleScanMode","standard-obd-only");
                }
                out.put("modules",modules);
                out.put("ok",true);
                jsCall("nativeQuickScan("+out.toString()+")");
                jsStatus("CarDoc all-systems scan complete.",true);
            }catch(Exception e){
                try{out.put("ok",false);out.put("error",e.getMessage()==null?"Scan failed":e.getMessage());}catch(Exception ignored){}
                jsCall("nativeQuickScan("+out.toString()+")");
                jsError("All-systems scan failed. Check the OBD2 connection and ignition.");
            }finally{
                restoreStandardCanHeader();
            }
        });
    }

    private void addUnique(List<String> list,String value){ if(value!=null&&!value.isEmpty()&&!list.contains(value))list.add(value); }

    private boolean isTransmissionDtc(String code){
        if(code==null)return false;String c=code.toUpperCase(Locale.ROOT);
        return c.matches("P07[0-9A-F]{2}")||c.matches("P17[0-9A-F]{2}");
    }

    private boolean isLikely11BitCan(String protocol){
        if(protocol==null)return false;String p=protocol.toUpperCase(Locale.ROOT);
        return p.contains("CAN")&&!p.contains("29 BIT")&&!p.contains("29-BIT")&&!p.contains("29BIT");
    }

    private JSONObject moduleJson(String type,boolean detected,String address,List<String> codes,String source)throws JSONException{
        JSONObject m=new JSONObject();m.put("type",type);m.put("detected",detected);m.put("address",address==null?"":address);m.put("source",source==null?"":source);m.put("codes",toJsonArray(codes));return m;
    }

    private JSONArray scanCommonReadOnlyModules(String manufacturer){
        JSONArray out=new JSONArray();
        String make=manufacturer==null?"":manufacturer.trim().toUpperCase(Locale.ROOT);
        LinkedHashMap<String,List<String>> targets=new LinkedHashMap<>();
        targets.put("transmission",new ArrayList<>(Arrays.asList("7E1")));
        if(make.contains("MAZDA")||make.contains("FORD")){
            targets.put("abs",new ArrayList<>(Arrays.asList("760","7B0")));
            targets.put("airbag",new ArrayList<>(Arrays.asList("737","7B2")));
            targets.put("steering",new ArrayList<>(Arrays.asList("730","7A0")));
            targets.put("bcm",new ArrayList<>(Arrays.asList("726","720","740")));
        }else if(make.contains("TOYOTA")||make.contains("LEXUS")){
            targets.put("abs",new ArrayList<>(Arrays.asList("7B0","760")));
            targets.put("airbag",new ArrayList<>(Arrays.asList("7B2","737")));
            targets.put("steering",new ArrayList<>(Arrays.asList("7A0","730")));
            targets.put("bcm",new ArrayList<>(Arrays.asList("720","726","740")));
        }else{
            targets.put("abs",new ArrayList<>(Arrays.asList("760","7B0")));
            targets.put("airbag",new ArrayList<>(Arrays.asList("737","7B2")));
            targets.put("steering",new ArrayList<>(Arrays.asList("730","7A0")));
            targets.put("bcm",new ArrayList<>(Arrays.asList("726","720","740")));
        }

        try{sendElm("ATH0",1200);}catch(Exception ignored){}
        try{sendElm("ATCAF1",1200);}catch(Exception ignored){}
        try{sendElm("ATCFC1",1200);}catch(Exception ignored){}

        for(Map.Entry<String,List<String>> entry:targets.entrySet()){
            String type=entry.getKey();boolean detected=false;String address="";List<String> dtcs=new ArrayList<>();
            for(String header:entry.getValue()){
                try{
                    sendElm("ATSH"+header,1200);
                    String raw=sendElm("1902FF",1900);
                    String compact=compactHex(raw);
                    if(compact.contains("5902")){
                        detected=true;address="0x"+header;
                        for(String c:decodeUdsDtcs(raw))addUnique(dtcs,c);
                        break;
                    }
                }catch(Exception ignored){}
            }
            try{out.put(moduleJson(type,detected,address,dtcs,"uds-readonly"));}catch(Exception ignored){}
        }
        return out;
    }

    private String compactHex(String raw){
        if(raw==null)return "";String upper=raw.toUpperCase(Locale.ROOT).replace("NO DATA"," ").replace("SEARCHING..."," ").replace("SEARCHING"," ");
        return upper.replaceAll("[^0-9A-F]","");
    }

    private List<String> decodeUdsDtcs(String raw){
        List<String> out=new ArrayList<>();String hex=compactHex(raw);int pos=hex.indexOf("5902");if(pos<0)return out;
        int i=pos+6; // 59 02 + DTCStatusAvailabilityMask
        while(i+7<hex.length()){
            try{
                int a=Integer.parseInt(hex.substring(i,i+2),16),b=Integer.parseInt(hex.substring(i+2,i+4),16),ftb=Integer.parseInt(hex.substring(i+4,i+6),16);
                int status=Integer.parseInt(hex.substring(i+6,i+8),16);
                if(a==0&&b==0&&ftb==0)break;
                String code=decodeDtcPair(a,b);
                if(code!=null&&!out.contains(code))out.add(code);
                i+=8;
                if(status<0)break;
            }catch(Exception e){break;}
        }
        return out;
    }

    private void restoreStandardCanHeader(){
        try{if(isLikely11BitCan(connectedProtocol))sendElm("ATSH7DF",1200);}catch(Exception ignored){}
        try{sendElm("ATH0",1200);}catch(Exception ignored){}
        try{sendElm("ATS0",1200);}catch(Exception ignored){}
    }

    private void batteryTestNative(){
        liveDataRunning=false; io.execute(()->{JSONObject o=new JSONObject();try{if(!isSocketConnected())throw new IllegalStateException("Not connected");double v=parseElmVoltage(cleanElmText(sendElm("ATRV",2500)));double rpm=0;try{Double r=queryPidValue(0x0C);if(r!=null)rpm=r;}catch(Exception ignored){}boolean running=rpm>450;String status="unknown";if(!Double.isNaN(v)){if(running){status=v<13.2?"low":(v>15.0?"high":"good");}else{status=v<12.0?"low":(v<12.4?"check":(v>13.2?"high":"good"));}}o.put("ok",true);o.put("voltage",v);o.put("rpm",rpm);o.put("engineRunning",running);o.put("status",status);}catch(Exception e){try{o.put("ok",false);}catch(Exception ignored){}}jsCall("nativeBatteryTest("+o.toString()+")");});
    }

    private void startLiveDataNative() {
        if (liveDataRunning) return;
        final int mySession = ++liveSession;
        liveDataRunning = true;

        liveIo.execute(() -> {
            try {
                if (!isSocketConnected()) {
                    liveDataRunning = false;
                    jsError("OBD2 is not connected.");
                    return;
                }

                Set<Integer> supported = discoverSupportedPids();

                JSONObject support = new JSONObject();
                support.put("rpm", supported.contains(0x0C));
                support.put("speed", supported.contains(0x0D));
                support.put("coolant", supported.contains(0x05));
                support.put("oilTemp", supported.contains(0x5C));
                support.put("voltage", supported.contains(0x42));
                support.put("load", supported.contains(0x04));
                support.put("throttle", supported.contains(0x11));
                support.put("intakeTemp", supported.contains(0x0F));
                support.put("map", supported.contains(0x0B));
                support.put("maf", supported.contains(0x10));
                support.put("fuelLevel", supported.contains(0x2F));
                support.put("stft1", supported.contains(0x06));
                support.put("ltft1", supported.contains(0x07));
                support.put("timing", supported.contains(0x0E));
                support.put("lambda", supported.contains(0x24) || supported.contains(0x44));
                support.put("fuelPressure", supported.contains(0x0A));
                support.put("runtime", supported.contains(0x1F));
                support.put("baro", supported.contains(0x33));
                support.put("ambient", supported.contains(0x46));
                support.put("absLoad", supported.contains(0x43));
                support.put("fuelRate", supported.contains(0x5E));
                support.put("ethanol", supported.contains(0x52));
                jsCall("nativeObdLiveSupport(" + support.toString() + ")");

                // Keep RPM and speed at the front of every cycle. Only ONE slower PID
                // is read between fast cycles so gauges are never held up by a long batch.
                final int[] bgPids = {0x04,0x11,0x0B,0x10,0x0E,0x05,0x5C,0x42,0x0F,0x2F,0x06,0x07,0x0A,0x1F,0x33,0x46,0x43,0x5E,0x52};
                final String[] bgKeys = {"load","throttle","map","maf","timing","coolant","oilTemp","voltage","intakeTemp","fuelLevel","stft1","ltft1","fuelPressure","runtime","baro","ambient","absLoad","fuelRate","ethanol"};
                int bgIndex = 0;
                int fastCycle = 0;
                int backgroundCycle = 0;

                while (liveDataRunning && mySession == liveSession && isSocketConnected()) {
                    // Priority gauges: push each reply immediately.
                    JSONObject rpmData = new JSONObject();
                    putPidValue(rpmData, "rpm", 0x0C, supported);
                    if (rpmData.length() > 0) {
                        rpmData.put("ts", System.currentTimeMillis());
                        jsCall("nativeObdLiveData(" + rpmData.toString() + ")");
                    }

                    JSONObject speedData = new JSONObject();
                    putPidValue(speedData, "speed", 0x0D, supported);
                    if (speedData.length() > 0) {
                        speedData.put("ts", System.currentTimeMillis());
                        jsCall("nativeObdLiveData(" + speedData.toString() + ")");
                    }

                    // Only one slower/background PID every 5 fast cycles.
                    if ((fastCycle++ % 5) == 0) {
                        JSONObject bgData = new JSONObject();
                        int pid = bgPids[bgIndex];
                        putPidValue(bgData, bgKeys[bgIndex], pid, supported);
                        bgIndex = (bgIndex + 1) % bgPids.length;
                        if ((backgroundCycle++ % 3) == 0) putLambdaValue(bgData, supported);
                        if (bgData.length() > 0) {
                            bgData.put("ts", System.currentTimeMillis());
                            jsCall("nativeObdLiveData(" + bgData.toString() + ")");
                        }
                    }
                    Thread.sleep(8);
                }
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            } catch (Exception e) {
                if (!isSocketConnected()) jsCall("nativeObdDisconnected()");
            } finally {
                if (mySession == liveSession) liveDataRunning = false;
            }
        });
    }

    private Set<Integer> discoverSupportedPids() {
        Set<Integer> supported = new HashSet<>();
        addSupportedRange(supported, 0x00);
        addSupportedRange(supported, 0x20);
        addSupportedRange(supported, 0x40);

        // Some low-cost ELM327 clones do not answer support bitmaps reliably.
        // If that happens, try the most common standard PIDs directly.
        if (supported.isEmpty()) {
            int[] fallback = {0x04,0x05,0x06,0x07,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F,0x10,0x11,0x1F,0x2F,0x33,0x42,0x43,0x46,0x52,0x5C,0x5E};
            for (int pid : fallback) supported.add(pid);
        }
        return supported;
    }

    private void addSupportedRange(Set<Integer> supported, int basePid) {
        try {
            String pidHex = String.format(Locale.ROOT, "%02X", basePid);
            String raw = sendElm("01" + pidHex, 1600);
            int[] bytes = extractPidBytes(raw, basePid, 4);
            if (bytes == null || bytes.length < 4) return;

            long mask = ((long)bytes[0] << 24)
                    | ((long)bytes[1] << 16)
                    | ((long)bytes[2] << 8)
                    | (long)bytes[3];

            for (int i = 0; i < 32; i++) {
                if ((mask & (1L << (31 - i))) != 0) {
                    supported.add(basePid + i + 1);
                }
            }
        } catch (Exception ignored) {}
    }

    private void putPidValue(JSONObject data, String key, int pid, Set<Integer> supported) {
        if (!supported.contains(pid)) return;
        try {
            Double value = queryPidValue(pid);
            if (value != null && !value.isNaN() && !value.isInfinite()) {
                data.put(key, Math.round(value * 10.0) / 10.0);
            }
        } catch (Exception ignored) {}
    }

    private void putLambdaValue(JSONObject data, Set<Integer> supported) {
        try {
            Double lambda = null;
            if (supported.contains(0x24)) {
                String raw = sendElm("0124", 700);
                int[] b = extractPidBytes(raw, 0x24, 4);
                if (b != null && b.length >= 4) {
                    lambda = ((b[0] * 256.0) + b[1]) / 32768.0;
                }
            } else if (supported.contains(0x44)) {
                String raw = sendElm("0144", 700);
                int[] b = extractPidBytes(raw, 0x44, 2);
                if (b != null && b.length >= 2) {
                    lambda = ((b[0] * 256.0) + b[1]) / 32768.0;
                }
            }
            if (lambda != null && lambda > 0.0 && lambda < 4.0) {
                data.put("lambda", Math.round(lambda * 1000.0) / 1000.0);
            }
        } catch (Exception ignored) {}
    }

    private Double queryPidValue(int pid) throws Exception {
        String pidHex = String.format(Locale.ROOT, "%02X", pid);
        long timeout = ((pid == 0x0C || pid == 0x0D) && fastLiveProtocol) ? 450 : 800;
        String raw = sendElm("01" + pidHex, timeout);

        int need = (pid == 0x0C || pid == 0x10 || pid == 0x1F || pid == 0x42 || pid == 0x43 || pid == 0x5E) ? 2 : 1;
        int[] b = extractPidBytes(raw, pid, need);
        if (b == null || b.length < need) return null;

        int a = b[0];
        int bb = need > 1 ? b[1] : 0;

        switch (pid) {
            case 0x04: return a * 100.0 / 255.0;                   // engine load %
            case 0x05: return (double)a - 40.0;                   // coolant C
            case 0x06:
            case 0x07: return (a - 128.0) * 100.0 / 128.0;        // fuel trim %
            case 0x0A: return a * 3.0;                           // fuel pressure kPa
            case 0x0B: return (double)a;                          // MAP kPa
            case 0x0C: return ((a * 256.0) + bb) / 4.0;           // RPM
            case 0x0D: return (double)a;                          // km/h
            case 0x0E: return a / 2.0 - 64.0;                     // timing advance deg
            case 0x0F: return (double)a - 40.0;                   // intake temp C
            case 0x10: return ((a * 256.0) + bb) / 100.0;         // MAF g/s
            case 0x11: return a * 100.0 / 255.0;                  // throttle %
            case 0x1F: return ((a * 256.0) + bb);                 // engine runtime seconds
            case 0x2F: return a * 100.0 / 255.0;                  // fuel level %
            case 0x33: return (double)a;                          // barometric pressure kPa
            case 0x42: return ((a * 256.0) + bb) / 1000.0;        // module voltage V
            case 0x43: return ((a * 256.0) + bb) * 100.0 / 255.0; // absolute load %
            case 0x46: return (double)a - 40.0;                   // ambient air temp C
            case 0x52: return a * 100.0 / 255.0;                  // ethanol %
            case 0x5C: return (double)a - 40.0;                   // engine oil temp C
            case 0x5E: return ((a * 256.0) + bb) / 20.0;          // fuel rate L/h
            default: return null;
        }
    }

    private int[] extractPidBytes(String raw, int pid, int count) {
        if (raw == null) return null;
        String compact = raw.toUpperCase(Locale.ROOT).replaceAll("[^0-9A-F]", "");
        String marker = "41" + String.format(Locale.ROOT, "%02X", pid);
        int pos = compact.indexOf(marker);
        if (pos < 0) return null;

        int start = pos + marker.length();
        if (compact.length() < start + count * 2) return null;

        int[] out = new int[count];
        try {
            for (int i = 0; i < count; i++) {
                out[i] = Integer.parseInt(compact.substring(start + i*2, start + i*2 + 2), 16);
            }
            return out;
        } catch (Exception e) {
            return null;
        }
    }



    private String findWorkingObdProtocol() throws Exception {
        // ELM327 protocol numbers:
        // 1 J1850 PWM, 2 J1850 VPW, 3 ISO 9141-2,
        // 4 KWP2000 5-baud init, 5 KWP2000 fast init,
        // 6 CAN 11/500, 7 CAN 29/500, 8 CAN 11/250, 9 CAN 29/250.
        // Try the most common modern CAN variants first, then KWP/ISO/J1850.
        String[][] protocols = new String[][] {
                {"6", "CAN 11-bit / 500 kbps", "4500"},
                {"7", "CAN 29-bit / 500 kbps", "4500"},
                {"8", "CAN 11-bit / 250 kbps", "4500"},
                {"9", "CAN 29-bit / 250 kbps", "4500"},
                {"5", "KWP2000 Fast Init", "6500"},
                {"4", "KWP2000 5-baud Init", "11000"},
                {"3", "ISO 9141-2", "11000"},
                {"1", "SAE J1850 PWM", "5500"},
                {"2", "SAE J1850 VPW", "5500"}
        };

        // If the user selected a connection profile, try it first but still fall back
        // to the full standard scan so a wrong profile cannot lock the user out.
        if (preferredProtocol != null && !"0".equals(preferredProtocol)) {
            for (int i = 0; i < protocols.length; i++) {
                if (preferredProtocol.equals(protocols[i][0])) {
                    String[] chosen = protocols[i];
                    for (int j = i; j > 0; j--) protocols[j] = protocols[j - 1];
                    protocols[0] = chosen;
                    break;
                }
            }
        }

        for (int i = 0; i < protocols.length; i++) {
            String id = protocols[i][0];
            String label = protocols[i][1];
            long timeout = Long.parseLong(protocols[i][2]);

            jsCall("nativeObdScanProgress("
                    + JSONObject.quote(label) + ","
                    + (i + 1) + ","
                    + protocols.length + ")");

            try {
                // Stop any previous protocol session and select this one explicitly.
                try { sendElm("ATPC", 1400); } catch (Exception ignored) {}
                sendElm("ATSP" + id, 1800);

                String probe = sendElm("0100", timeout);
                if (hasPidResponse(probe, "4100")) {
                    String detected = label;
                    try {
                        String elmName = cleanElmText(sendElm("ATDP", 1800));
                        if (!elmName.isEmpty() && !elmName.equalsIgnoreCase("AUTO")) {
                            detected = elmName;
                        }
                    } catch (Exception ignored) {}
                    return detected;
                }

                // A few ECUs/clones answer a normal live PID even when 0100 behaves oddly.
                if (!isElmConnectionFailure(probe)) {
                    try {
                        String rpmProbe = sendElm("010C", Math.min(timeout, 6000));
                        if (hasPidResponse(rpmProbe, "410C")) {
                            String detected = label;
                            try {
                                String elmName = cleanElmText(sendElm("ATDP", 1800));
                                if (!elmName.isEmpty() && !elmName.equalsIgnoreCase("AUTO")) {
                                    detected = elmName;
                                }
                            } catch (Exception ignored) {}
                            return detected;
                        }
                    } catch (Exception ignored) {}
                }
            } catch (Exception ignored) {
                // Continue with the next standard protocol.
            }
        }

        // Last fallback: let a genuine ELM327 try its own automatic search.
        jsCall("nativeObdScanProgress(" + JSONObject.quote("ELM327 Auto") + ",10,10)");
        try {
            sendElm("ATSP0", 1800);
            String autoProbe = sendElm("0100", 15000);
            if (hasPidResponse(autoProbe, "4100")) {
                String detected = "Automatic";
                try {
                    String elmName = cleanElmText(sendElm("ATDP", 1800));
                    if (!elmName.isEmpty()) detected = elmName;
                } catch (Exception ignored) {}
                return detected;
            }
        } catch (Exception ignored) {}

        return null;
    }

    private boolean hasPidResponse(String raw, String marker) {
        if (raw == null) return false;
        String upper = raw.toUpperCase(Locale.ROOT);
        if (isElmConnectionFailure(upper)) return false;
        String compact = upper.replaceAll("[^0-9A-F]", "");
        return compact.contains(marker);
    }

    private boolean isElmConnectionFailure(String raw) {
        if (raw == null) return true;
        String s = raw.toUpperCase(Locale.ROOT);
        return s.contains("UNABLE TO CONNECT")
                || s.contains("NO DATA")
                || s.contains("BUS ERROR")
                || (s.contains("BUS INIT") && s.contains("ERROR"))
                || s.contains("CAN ERROR")
                || s.contains("ERROR")
                || s.contains("STOPPED");
    }

    private String cleanElmText(String raw) {
        if (raw == null) return "";
        return raw.replace(">", " ")
                .replace("\r", " ")
                .replace("\n", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private synchronized String sendElm(String command, long timeoutMs) throws Exception {
        if (!isSocketConnected()) throw new IllegalStateException("Not connected");
        if ("BLE".equals(connectionTransport)) return sendBleElm(command, timeoutMs);
        if ("USB".equals(connectionTransport)) return sendUsbElm(command, timeoutMs);
        InputStream in = activeInputStream();
        OutputStream outStream = activeOutputStream();
        if (in == null || outStream == null) throw new IllegalStateException("Not connected");

        while (in.available() > 0) {
            byte[] junk = new byte[Math.min(512, in.available())];
            in.read(junk);
        }

        outStream.write((command + "\r").getBytes(StandardCharsets.US_ASCII));
        outStream.flush();

        StringBuilder out = new StringBuilder();
        long end = System.currentTimeMillis() + timeoutMs;
        byte[] buffer = new byte[512];
        while (System.currentTimeMillis() < end) {
            int available = in.available();
            if (available > 0) {
                int n = in.read(buffer, 0, Math.min(buffer.length, available));
                if (n > 0) {
                    out.append(new String(buffer, 0, n, StandardCharsets.US_ASCII));
                    if (out.indexOf(">") >= 0) break;
                }
            } else {
                Thread.sleep(25);
            }
        }
        if (out.length() == 0) throw new Exception("OBD timeout");
        return out.toString();
    }

    private InputStream activeInputStream() {
        if (wifiSocket != null && wifiSocket.isConnected() && !wifiSocket.isClosed()) return wifiIn;
        return btIn;
    }

    private OutputStream activeOutputStream() {
        if (wifiSocket != null && wifiSocket.isConnected() && !wifiSocket.isClosed()) return wifiOut;
        return btOut;
    }

    private List<String> decodeDtcs(String raw) {
        return decodeDtcsFromMode(raw, "43");
    }

    private List<String> decodeDtcsFromMode(String raw, String responseMode) {
        List<String> codes = new ArrayList<>();
        if (raw == null) return codes;

        String upper = raw.toUpperCase(Locale.ROOT)
                .replace("SEARCHING...", " ")
                .replace("SEARCHING", " ")
                .replace("NO DATA", " ")
                .replace(">", " ");
        String[] parts = upper.split("[^0-9A-F]+");
        List<String> bytes = new ArrayList<>();
        for (String p : parts) if (p.matches("[0-9A-F]{2}")) bytes.add(p);

        for (int i = 0; i < bytes.size(); i++) {
            if (!responseMode.equals(bytes.get(i))) continue;
            int j = i + 1;
            while (j + 1 < bytes.size()) {
                if (responseMode.equals(bytes.get(j))) break;
                int a, b;
                try {
                    a = Integer.parseInt(bytes.get(j), 16);
                    b = Integer.parseInt(bytes.get(j + 1), 16);
                } catch (Exception e) { break; }
                if (a == 0 && b == 0) break;
                String dtc = decodeDtcPair(a, b);
                if (dtc != null && !codes.contains(dtc)) codes.add(dtc);
                j += 2;
            }
        }
        return codes;
    }

    private String decodeDtcPair(int a, int b) {
        char[] systems = {'P','C','B','U'};
        char system = systems[(a >> 6) & 0x03];
        int digit1 = (a >> 4) & 0x03;
        int digit2 = a & 0x0F;
        int digit3 = (b >> 4) & 0x0F;
        int digit4 = b & 0x0F;
        return "" + system + digit1 + Integer.toHexString(digit2).toUpperCase(Locale.ROOT)
                + Integer.toHexString(digit3).toUpperCase(Locale.ROOT)
                + Integer.toHexString(digit4).toUpperCase(Locale.ROOT);
    }

    private String normalizeManufacturerForDb(String make) {
        if (make == null) return "";
        String s = make.trim().toUpperCase(Locale.ROOT);
        if (s.isEmpty()) return "";
        if (s.contains("DATSUN")) return "NISSAN";
        if (s.equals("VW") || s.contains("VOLKSWAGEN")) return "VOLKSWAGEN";
        if (s.contains("MERCEDES")) return "MERCEDES-BENZ";
        if (s.contains("CHEVY") || s.contains("CHEVROLET")) return "CHEVROLET";
        if (s.contains("LAND ROVER") || s.contains("RANGE ROVER")) return "LAND ROVER";
        String[] known = {"HONDA","NISSAN","TOYOTA","MAZDA","FORD","BMW","AUDI","SUBARU","MITSUBISHI","VOLVO","LEXUS","INFINITI","ACURA","HYUNDAI","KIA","JEEP","CHRYSLER","DODGE","GMC"};
        for (String k : known) if (s.contains(k)) return k;
        return s.replaceAll("\\s+", " ");
    }

    private SQLiteDatabase getDtcDatabase() {
        synchronized (this) {
            if (dtcDatabase != null && dtcDatabase.isOpen()) return dtcDatabase;
            try {
                File target = getDatabasePath("cardoc_dtc_codes.db");
                if (!target.exists() || target.length() < 1000000) {
                    File parent = target.getParentFile();
                    if (parent != null) parent.mkdirs();
                    try (InputStream in = getAssets().open("dtc_codes.db"); FileOutputStream out = new FileOutputStream(target, false)) {
                        byte[] buf = new byte[16384];
                        int n;
                        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                        out.flush();
                    }
                }
                dtcDatabase = SQLiteDatabase.openDatabase(target.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
                return dtcDatabase;
            } catch (Exception e) { return null; }
        }
    }

    private int getDtcDefinitionCountNative() {
        SQLiteDatabase db = getDtcDatabase();
        if (db == null) return 0;
        try (Cursor c = db.rawQuery("SELECT COUNT(*) FROM dtc_definitions WHERE locale='en'", null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        } catch (Exception e) { return 0; }
    }

    private String lookupDtcJson(String code, String manufacturer) {
        if (code == null) return "";
        String normalizedCode = code.trim().toUpperCase(Locale.ROOT);
        if (!normalizedCode.matches("^[PCBU][0-3][0-9A-F]{3}$")) return "";
        SQLiteDatabase db = getDtcDatabase();
        if (db == null) return "";
        String make = normalizeManufacturerForDb(manufacturer);
        Cursor c = null;
        try {
            if (!make.isEmpty()) {
                c = db.rawQuery("SELECT code,description,type,manufacturer,is_generic FROM dtc_definitions WHERE code=? AND manufacturer=? AND locale='en' LIMIT 1", new String[]{normalizedCode, make});
                if (!c.moveToFirst()) { c.close(); c = null; }
            }
            if (c == null) {
                c = db.rawQuery("SELECT code,description,type,manufacturer,is_generic FROM dtc_definitions WHERE code=? AND manufacturer='GENERIC' AND locale='en' LIMIT 1", new String[]{normalizedCode});
                if (!c.moveToFirst()) { c.close(); c = null; }
            }
            if (c == null) return "";
            String rowCode=c.getString(0), description=c.getString(1), type=c.getString(2), rowMake=c.getString(3);
            boolean generic=c.getInt(4)==1 || "GENERIC".equalsIgnoreCase(rowMake);
            JSONObject o=new JSONObject();
            o.put("code",rowCode); o.put("description",description==null?"":description); o.put("category",dtcTypeName(type));
            o.put("manufacturer",generic?"":rowMake); o.put("specific",!generic); o.put("source","extended");
            return o.toString();
        } catch (Exception e) { return ""; }
        finally { try { if (c != null) c.close(); } catch (Exception ignored) {} }
    }

    private String dtcTypeName(String type) {
        if (type == null || type.isEmpty()) return "Unknown";
        switch (Character.toUpperCase(type.charAt(0))) {
            case 'P': return "Powertrain"; case 'B': return "Body"; case 'C': return "Chassis"; case 'U': return "Network"; default: return "Unknown";
        }
    }

    private boolean isSocketConnected() {
        boolean bt = btSocket != null && btSocket.isConnected();
        boolean wifi = wifiSocket != null && wifiSocket.isConnected() && !wifiSocket.isClosed();
        boolean ble = bleReady && bleGatt != null;
        boolean usb = usbPort != null && usbPort.isOpen();
        return bt || wifi || ble || usb;
    }

    private void disconnectNative(boolean notifyJs) {
        io.execute(() -> {
            disconnectSocketOnly();
            if (notifyJs) jsCall("nativeObdDisconnected()");
        });
    }

    private void disconnectSocketOnly() {
        liveSession++;
        liveDataRunning = false;
        try { if (btIn != null) btIn.close(); } catch (Exception ignored) {}
        try { if (btOut != null) btOut.close(); } catch (Exception ignored) {}
        closeQuietly(btSocket);
        try { if (wifiIn != null) wifiIn.close(); } catch (Exception ignored) {}
        try { if (wifiOut != null) wifiOut.close(); } catch (Exception ignored) {}
        try { if (wifiSocket != null) wifiSocket.close(); } catch (Exception ignored) {}
        try { if (bleGatt != null) { bleGatt.disconnect(); bleGatt.close(); } } catch (Exception ignored) {}
        try { if (usbPort != null) usbPort.close(); } catch (Exception ignored) {}
        try { if (usbConnection != null) usbConnection.close(); } catch (Exception ignored) {}
        btIn = null; btOut = null; btSocket = null;
        wifiIn = null; wifiOut = null; wifiSocket = null;
        bleGatt = null; bleWriteChar = null; bleNotifyChar = null; bleReady = false;
        usbPort = null; usbConnection = null;
        connectionTransport = "";
        connectedProtocol = "";
        fastLiveProtocol = false;
    }

    private void closeQuietly(BluetoothSocket socket) {
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
    }

    private void jsStatus(String message, boolean connected) {
        jsCall("nativeObdStatus(" + JSONObject.quote(message) + "," + connected + ")");
    }

    private void jsError(String message) {
        jsCall("nativeObdError(" + JSONObject.quote(message) + ")");
    }

    private void jsCall(String code) {
        main.post(() -> webView.evaluateJavascript("window." + code, null));
    }

    @Override public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("window.handleAppBack ? window.handleAppBack() : null", null);
        }
    }

    @Override protected void onDestroy() {
        stopDiscovery();
        stopBleScan();
        disconnectSocketOnly();
        io.shutdownNow();
        liveIo.shutdownNow();
        translationIo.shutdownNow();
        if (receiverRegistered) {
            try { unregisterReceiver(btReceiver); } catch (Exception ignored) {}
        }
        if (usbReceiverRegistered) {
            try { unregisterReceiver(usbReceiver); } catch (Exception ignored) {}
        }
        try { if (dtcDatabase != null) dtcDatabase.close(); } catch (Exception ignored) {}
        try { for (Translator translator : translators.values()) if (translator != null) translator.close(); } catch (Exception ignored) {}
        translators.clear();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
