package com.cardoc.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_BT_PERMS = 101;
    private static final int REQ_ENABLE_BT = 102;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private WebView webView;
    private BluetoothAdapter btAdapter;
    private BluetoothSocket btSocket;
    private InputStream btIn;
    private OutputStream btOut;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ExecutorService liveIo = Executors.newSingleThreadExecutor();
    private volatile boolean liveDataRunning = false;
    private final Handler main = new Handler(Looper.getMainLooper());

    private final List<BluetoothDevice> foundDevices = new ArrayList<>();
    private final Set<String> foundAddresses = new HashSet<>();
    private ArrayAdapter<String> deviceListAdapter;
    private AlertDialog deviceDialog;
    private Runnable pendingPermissionAction;
    private boolean receiverRegistered = false;
    private String connectedName = "OBD2";

    private final BroadcastReceiver btReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device;
                if (Build.VERSION.SDK_INT >= 33) {
                    device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
                } else {
                    device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                }
                if (device != null) addDevice(device);
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                jsStatus("Scan finished. Select your OBD2 adapter.", false);
            }
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        btAdapter = manager != null ? manager.getAdapter() : null;

        webView = new WebView(this);
        setContentView(webView);
        webView.setBackgroundColor(0xFF08111F);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowFileAccessFromFileURLs(true);
        webView.getSettings().setAllowUniversalAccessFromFileURLs(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new ObdBridge(), "AndroidOBD");
        webView.loadUrl("file:///android_asset/index.html");

        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(btReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(btReceiver, filter);
        }
        receiverRegistered = true;
    }

    public class ObdBridge {
        @JavascriptInterface public void scanBluetooth() {
            main.post(() -> ensureBluetoothReady(MainActivity.this::showDevicePicker));
        }

        @JavascriptInterface public void readCodes() {
            readCodesNative();
        }

        @JavascriptInterface public void clearCodes() {
            clearCodesNative();
        }

        @JavascriptInterface public void readPendingPermanent() {
            readPendingPermanentNative();
        }

        @JavascriptInterface public void readFreezeFrame() {
            readFreezeFrameNative();
        }

        @JavascriptInterface public void readReadiness() {
            readReadinessNative();
        }

        @JavascriptInterface public void readVin() {
            readVinNative();
        }

        @JavascriptInterface public void disconnect() {
            disconnectNative(true);
        }

        @JavascriptInterface public void exitApp() {
            liveDataRunning = false;
            main.post(() -> {
                stopDiscovery();
                disconnectSocketOnly();
                finishAndRemoveTask();
            });
        }

        @JavascriptInterface public void startLiveData() {
            startLiveDataNative();
        }

        @JavascriptInterface public void stopLiveData() {
            liveDataRunning = false;
        }

        @JavascriptInterface public String getAssetText(String name) {
            if (!"codes.json".equals(name) && !"symptoms.json".equals(name) && !"parts-map.json".equals(name)) return "";
            try (InputStream in = getAssets().open(name);
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) != -1) {
                    out.write(buffer, 0, n);
                }
                return out.toString(StandardCharsets.UTF_8.name());
            } catch (Exception e) {
                return "";
            }
        }
    }

    private void ensureBluetoothReady(Runnable action) {
        if (btAdapter == null) {
            jsError("Bluetooth is not available on this device.");
            return;
        }
        if (!hasBtPermissions()) {
            pendingPermissionAction = action;
            requestBtPermissions();
            return;
        }
        if (!btAdapter.isEnabled()) {
            pendingPermissionAction = action;
            try {
                startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_ENABLE_BT);
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            }
            return;
        }
        action.run();
    }

    private boolean hasBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT_PERMS);
        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_BT_PERMS);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT_PERMS) {
            if (hasBtPermissions()) {
                Runnable r = pendingPermissionAction;
                pendingPermissionAction = null;
                if (r != null) ensureBluetoothReady(r);
            } else {
                jsError("Bluetooth permission is required to find the OBD2 adapter.");
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_ENABLE_BT) {
            Runnable r = pendingPermissionAction;
            pendingPermissionAction = null;
            if (btAdapter != null && btAdapter.isEnabled() && r != null) r.run();
            else jsError("Bluetooth is turned off.");
        }
    }

    private void showDevicePicker() {
        foundDevices.clear();
        foundAddresses.clear();

        ListView listView = new ListView(this);
        deviceListAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_2, android.R.id.text1, new ArrayList<>());
        listView.setAdapter(deviceListAdapter);

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("Select OBD2 Bluetooth device")
                .setView(listView)
                .setNegativeButton("Cancel", (d, w) -> stopDiscovery());
        deviceDialog = builder.create();
        deviceDialog.setOnDismissListener(d -> stopDiscovery());
        deviceDialog.show();

        // Paired devices appear immediately.
        try {
            Set<BluetoothDevice> bonded = btAdapter.getBondedDevices();
            if (bonded != null) {
                List<BluetoothDevice> sorted = new ArrayList<>(bonded);
                sortObdFirst(sorted);
                for (BluetoothDevice d : sorted) addDevice(d);
            }
        } catch (SecurityException ignored) {}

        listView.setOnItemClickListener((parent, view, position, id) -> {
            if (position < 0 || position >= foundDevices.size()) return;
            BluetoothDevice selected = foundDevices.get(position);
            stopDiscovery();
            if (deviceDialog != null) deviceDialog.dismiss();
            connectClassic(selected);
        });

        jsStatus("Searching Bluetooth devices…", false);
        try {
            if (btAdapter.isDiscovering()) btAdapter.cancelDiscovery();
            btAdapter.startDiscovery();
        } catch (SecurityException e) {
            jsError("Bluetooth scan permission is missing.");
        }
    }

    private void addDevice(BluetoothDevice device) {
        main.post(() -> {
            try {
                String address = device.getAddress();
                if (address == null || foundAddresses.contains(address)) return;
                String name = device.getName();
                if (name == null || name.trim().isEmpty()) name = "Unknown Bluetooth device";

                // Put OBD-like names near the top while still showing all Classic devices.
                int insertAt = looksLikeObd(name) ? firstNonObdIndex() : foundDevices.size();
                foundAddresses.add(address);
                foundDevices.add(insertAt, device);
                deviceListAdapter.insert(name + "\n" + address, insertAt);
                deviceListAdapter.notifyDataSetChanged();
            } catch (SecurityException ignored) {}
        });
    }

    private int firstNonObdIndex() {
        for (int i = 0; i < foundDevices.size(); i++) {
            try {
                String n = foundDevices.get(i).getName();
                if (!looksLikeObd(n)) return i;
            } catch (SecurityException e) { return i; }
        }
        return foundDevices.size();
    }

    private boolean looksLikeObd(String name) {
        if (name == null) return false;
        String n = name.toUpperCase(Locale.ROOT);
        return n.contains("OBD") || n.contains("ELM") || n.contains("V-LINK") || n.contains("VLINK")
                || n.contains("VGATE") || n.contains("ICAR") || n.contains("VIECAR") || n.contains("VEEPEAK")
                || n.contains("KONNWEI") || n.contains("CARISTA");
    }

    private void sortObdFirst(List<BluetoothDevice> list) {
        Collections.sort(list, (a,b) -> {
            try {
                boolean ao = looksLikeObd(a.getName());
                boolean bo = looksLikeObd(b.getName());
                if (ao == bo) return 0;
                return ao ? -1 : 1;
            } catch (SecurityException e) { return 0; }
        });
    }

    private void stopDiscovery() {
        try {
            if (btAdapter != null && btAdapter.isDiscovering()) btAdapter.cancelDiscovery();
        } catch (SecurityException ignored) {}
    }

    private void connectClassic(BluetoothDevice device) {
        jsStatus("Connecting to OBD2…", false);
        io.execute(() -> {
            disconnectSocketOnly();
            stopDiscovery();
            BluetoothSocket socket = null;
            Exception last = null;

            try {
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                socket.connect();
            } catch (Exception e) {
                last = e;
                closeQuietly(socket);
                try {
                    socket = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
                    socket.connect();
                } catch (Exception e2) {
                    last = e2;
                    closeQuietly(socket);
                    socket = null;
                }
            }

            if (socket == null || !socket.isConnected()) {
                jsError("Could not connect to this Bluetooth device. Pair the OBD2 adapter in Android Bluetooth settings first, then try again.");
                return;
            }

            try {
                btSocket = socket;
                btIn = socket.getInputStream();
                btOut = socket.getOutputStream();
                try { connectedName = device.getName(); } catch (SecurityException ignored) { connectedName = "OBD2"; }
                if (connectedName == null || connectedName.trim().isEmpty()) connectedName = "OBD2";

                sendElm("ATZ", 3200);
                sendElm("ATE0", 1400);
                sendElm("ATL0", 1400);
                sendElm("ATS0", 1400);
                sendElm("ATH0", 1400);
                sendElm("ATAT1", 1400);

                // Universal OBD-II protocol scan.
                // Explicitly try every standard passenger-car ELM327 protocol instead
                // of depending only on ATSP0 auto-detection.
                String protocol = findWorkingObdProtocol();
                if (protocol == null || protocol.isEmpty()) {
                    throw new Exception("NO_ECU_PROTOCOL");
                }

                jsCall("nativeObdConnected(" + JSONObject.quote(connectedName) + ")");
                jsCall("nativeObdProtocol(" + JSONObject.quote(protocol) + ")");
                readCodesNative();
                readVinNative();
            } catch (Exception e) {
                if ("NO_ECU_PROTOCOL".equals(e.getMessage())) {
                    jsError("Bluetooth adapter connected, but no standard OBD-II ECU protocol responded. Check ignition and vehicle OBD-II compatibility.");
                } else {
                    jsError("Connected to Bluetooth, but the OBD2 adapter did not respond correctly as an ELM327/SPP device.");
                }
                disconnectSocketOnly();
            }
        });
    }

    private void readCodesNative() {
        // Do not let continuous live PID polling compete with Mode 03.
        liveDataRunning = false;
        io.execute(() -> {
            if (!isSocketConnected()) {
                jsError("OBD2 is not connected.");
                return;
            }
            try {
                Thread.sleep(180);
                jsStatus("Reading stored engine trouble codes…", true);
                String raw = sendElm("03", 10000);
                if (isElmConnectionFailure(raw)) {
                    jsError("Adapter is connected, but the vehicle ECU did not answer. Keep ignition ON and try again.");
                    return;
                }
                List<String> codes = decodeDtcs(raw);
                JSONArray arr = new JSONArray();
                for (String code : codes) arr.put(code);
                jsCall("nativeObdCodes(" + arr.toString() + ")");
            } catch (Exception e) {
                jsError("Could not read OBD2 codes. Keep ignition ON and try again.");
            }
        });
    }

    private void clearCodesNative() {
        // Mode 04 should have the link to itself; pause live data first.
        liveDataRunning = false;
        io.execute(() -> {
            if (!isSocketConnected()) {
                jsError("OBD2 is not connected.");
                return;
            }
            try {
                Thread.sleep(180);
                jsStatus("Clearing stored engine/emissions codes…", true);
                String clearRaw = sendElm("04", 10000);
                if (isElmConnectionFailure(clearRaw) || clearRaw.toUpperCase(Locale.ROOT).contains("?")) {
                    jsError("The vehicle ECU did not accept the clear command.");
                    return;
                }

                Thread.sleep(1600);
                String raw = sendElm("03", 10000);
                if (isElmConnectionFailure(raw)) {
                    jsError("Codes were sent a clear command, but the ECU could not be re-read.");
                    return;
                }

                List<String> codes = decodeDtcs(raw);
                JSONArray arr = new JSONArray();
                for (String code : codes) arr.put(code);
                jsCall("nativeObdCodes(" + arr.toString() + ")");
            } catch (Exception e) {
                jsError("Could not clear the codes. Keep ignition ON and try again.");
            }
        });
    }



    private void readPendingPermanentNative() {
        liveDataRunning = false;
        io.execute(() -> {
            if (!isSocketConnected()) {
                jsError("OBD2 is not connected.");
                return;
            }

            JSONArray pending = new JSONArray();
            JSONArray permanent = new JSONArray();
            boolean pendingSupported = true;
            boolean permanentSupported = true;

            try {
                String raw = sendElm("07", 8000);
                String u = raw == null ? "" : raw.toUpperCase(Locale.ROOT);
                if (u.contains("NO DATA") || u.contains("?") || u.contains("UNABLE TO CONNECT")) {
                    pendingSupported = false;
                } else {
                    for (String code : decodeDtcsFromMode(raw, "47")) pending.put(code);
                }
            } catch (Exception e) {
                pendingSupported = false;
            }

            try {
                String raw = sendElm("0A", 8000);
                String u = raw == null ? "" : raw.toUpperCase(Locale.ROOT);
                if (u.contains("NO DATA") || u.contains("?") || u.contains("UNABLE TO CONNECT")) {
                    permanentSupported = false;
                } else {
                    for (String code : decodeDtcsFromMode(raw, "4A")) permanent.put(code);
                }
            } catch (Exception e) {
                permanentSupported = false;
            }

            try {
                JSONObject out = new JSONObject();
                out.put("pending", pending);
                out.put("permanent", permanent);
                out.put("pendingSupported", pendingSupported);
                out.put("permanentSupported", permanentSupported);
                jsCall("nativeObdExtraCodes(" + out.toString() + ")");
            } catch (Exception ignored) {}
        });
    }

    private void readFreezeFrameNative() {
        liveDataRunning = false;
        io.execute(() -> {
            if (!isSocketConnected()) {
                jsError("OBD2 is not connected.");
                return;
            }

            JSONObject out = new JSONObject();
            boolean any = false;

            try {
                String raw = "";
                try { raw = sendElm("020200", 4500); } catch (Exception ignored) {}
                int[] dtcBytes = extractMode02PidBytes(raw, 0x02, 2);
                if (dtcBytes == null) {
                    try {
                        raw = sendElm("0202", 4500);
                        dtcBytes = extractMode02PidBytes(raw, 0x02, 2);
                    } catch (Exception ignored) {}
                }
                if (dtcBytes != null && dtcBytes.length >= 2) {
                    String dtc = decodeDtcPair(dtcBytes[0], dtcBytes[1]);
                    if (dtc != null && !"P0000".equals(dtc)) {
                        out.put("dtc", dtc);
                        any = true;
                    }
                }

                any |= putFreezePid(out, "load", 0x04);
                any |= putFreezePid(out, "coolant", 0x05);
                any |= putFreezePid(out, "stft1", 0x06);
                any |= putFreezePid(out, "ltft1", 0x07);
                any |= putFreezePid(out, "map", 0x0B);
                any |= putFreezePid(out, "rpm", 0x0C);
                any |= putFreezePid(out, "speed", 0x0D);
                any |= putFreezePid(out, "intakeTemp", 0x0F);
                any |= putFreezePid(out, "maf", 0x10);
                any |= putFreezePid(out, "throttle", 0x11);
            } catch (Exception ignored) {}

            try {
                out.put("available", any);
                jsCall("nativeObdFreezeFrame(" + out.toString() + ")");
            } catch (Exception ignored) {}
        });
    }

    private boolean putFreezePid(JSONObject out, String key, int pid) {
        try {
            String cmd = "02" + String.format(Locale.ROOT, "%02X", pid) + "00";
            String raw = sendElm(cmd, 2600);
            int need = (pid == 0x0C || pid == 0x10) ? 2 : 1;
            int[] b = extractMode02PidBytes(raw, pid, need);
            if (b == null || b.length < need) return false;

            int a = b[0];
            int bb = need > 1 ? b[1] : 0;
            Double value = null;

            switch (pid) {
                case 0x04: value = a * 100.0 / 255.0; break;
                case 0x05: value = (double)a - 40.0; break;
                case 0x06:
                case 0x07: value = (a - 128.0) * 100.0 / 128.0; break;
                case 0x0B: value = (double)a; break;
                case 0x0C: value = ((a * 256.0) + bb) / 4.0; break;
                case 0x0D: value = (double)a; break;
                case 0x0F: value = (double)a - 40.0; break;
                case 0x10: value = ((a * 256.0) + bb) / 100.0; break;
                case 0x11: value = a * 100.0 / 255.0; break;
            }

            if (value != null) {
                out.put(key, Math.round(value * 10.0) / 10.0);
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private int[] extractMode02PidBytes(String raw, int pid, int count) {
        if (raw == null) return null;
        String compact = raw.toUpperCase(Locale.ROOT).replaceAll("[^0-9A-F]", "");
        String marker = "42" + String.format(Locale.ROOT, "%02X", pid);
        int pos = compact.indexOf(marker);
        if (pos < 0) return null;
        int start = pos + marker.length();

        if (compact.length() >= start + (count + 1) * 2) {
            String maybeFrame = compact.substring(start, start + 2);
            if ("00".equals(maybeFrame) || "01".equals(maybeFrame) || "02".equals(maybeFrame)) {
                start += 2;
            }
        }

        if (compact.length() < start + count * 2) return null;
        int[] out = new int[count];
        try {
            for (int i = 0; i < count; i++) {
                out[i] = Integer.parseInt(compact.substring(start + i * 2, start + i * 2 + 2), 16);
            }
            return out;
        } catch (Exception e) {
            return null;
        }
    }

    private void readReadinessNative() {
        liveDataRunning = false;
        io.execute(() -> {
            if (!isSocketConnected()) {
                jsError("OBD2 is not connected.");
                return;
            }

            JSONObject out = new JSONObject();
            try {
                String raw = sendElm("0101", 4500);
                int[] b = extractPidBytes(raw, 0x01, 4);
                if (b == null || b.length < 4) {
                    out.put("available", false);
                    jsCall("nativeObdReadiness(" + out.toString() + ")");
                    return;
                }

                int a = b[0], bb = b[1], c = b[2], d = b[3];
                boolean compression = (bb & 0x08) != 0;
                out.put("available", true);
                out.put("mil", (a & 0x80) != 0);
                out.put("dtcCount", a & 0x7F);
                out.put("engineType", compression ? "compression" : "spark");

                JSONArray monitors = new JSONArray();
                addReadinessMonitor(monitors, "misfire", (bb & 0x01) != 0, (bb & 0x10) == 0);
                addReadinessMonitor(monitors, "fuelSystem", (bb & 0x02) != 0, (bb & 0x20) == 0);
                addReadinessMonitor(monitors, "components", (bb & 0x04) != 0, (bb & 0x40) == 0);

                if (!compression) {
                    addReadinessMonitor(monitors, "catalyst", (c & 0x01) != 0, (d & 0x01) == 0);
                    addReadinessMonitor(monitors, "heatedCatalyst", (c & 0x02) != 0, (d & 0x02) == 0);
                    addReadinessMonitor(monitors, "evap", (c & 0x04) != 0, (d & 0x04) == 0);
                    addReadinessMonitor(monitors, "secondaryAir", (c & 0x08) != 0, (d & 0x08) == 0);
                    addReadinessMonitor(monitors, "acRefrigerant", (c & 0x10) != 0, (d & 0x10) == 0);
                    addReadinessMonitor(monitors, "o2Sensor", (c & 0x20) != 0, (d & 0x20) == 0);
                    addReadinessMonitor(monitors, "o2Heater", (c & 0x40) != 0, (d & 0x40) == 0);
                    addReadinessMonitor(monitors, "egrVvt", (c & 0x80) != 0, (d & 0x80) == 0);
                } else {
                    addReadinessMonitor(monitors, "nmhcCatalyst", (c & 0x01) != 0, (d & 0x01) == 0);
                    addReadinessMonitor(monitors, "noxScr", (c & 0x02) != 0, (d & 0x02) == 0);
                    addReadinessMonitor(monitors, "boostPressure", (c & 0x08) != 0, (d & 0x08) == 0);
                    addReadinessMonitor(monitors, "exhaustGasSensor", (c & 0x20) != 0, (d & 0x20) == 0);
                    addReadinessMonitor(monitors, "pmFilter", (c & 0x40) != 0, (d & 0x40) == 0);
                    addReadinessMonitor(monitors, "egrVvt", (c & 0x80) != 0, (d & 0x80) == 0);
                }

                out.put("monitors", monitors);
            } catch (Exception e) {
                try { out.put("available", false); } catch (Exception ignored) {}
            }
            jsCall("nativeObdReadiness(" + out.toString() + ")");
        });
    }

    private void addReadinessMonitor(JSONArray arr, String id, boolean supported, boolean complete) {
        try {
            JSONObject m = new JSONObject();
            m.put("id", id);
            m.put("supported", supported);
            m.put("complete", supported && complete);
            arr.put(m);
        } catch (Exception ignored) {}
    }

    private void readVinNative() {
        liveDataRunning = false;
        io.execute(() -> {
            if (!isSocketConnected()) return;
            String vin = "";
            try {
                String raw = sendElm("0902", 9000);
                vin = decodeVin(raw);
            } catch (Exception ignored) {}
            jsCall("nativeObdVin(" + JSONObject.quote(vin) + ")");
        });
    }

    private String decodeVin(String raw) {
        if (raw == null) return "";
        String upper = raw.toUpperCase(Locale.ROOT)
                .replace("SEARCHING...", " ")
                .replace("SEARCHING", " ")
                .replace("NO DATA", " ")
                .replace(">", " ");
        String[] parts = upper.split("[^0-9A-F]+");
        List<String> bytes = new ArrayList<>();
        for (String p : parts) if (p.matches("[0-9A-F]{2}")) bytes.add(p);

        StringBuilder chars = new StringBuilder();
        for (int i = 0; i + 2 < bytes.size(); i++) {
            if (!"49".equals(bytes.get(i)) || !"02".equals(bytes.get(i + 1))) continue;
            int j = i + 2;
            if (j < bytes.size()) j++;
            while (j < bytes.size()) {
                if (j + 1 < bytes.size() && "49".equals(bytes.get(j)) && "02".equals(bytes.get(j + 1))) break;
                try {
                    int v = Integer.parseInt(bytes.get(j), 16);
                    char ch = (char)v;
                    if ((ch >= '0' && ch <= '9') || (ch >= 'A' && ch <= 'Z')) chars.append(ch);
                } catch (Exception ignored) {}
                j++;
            }
        }

        String s = chars.toString();
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("[A-HJ-NPR-Z0-9]{17}").matcher(s);
        return m.find() ? m.group() : "";
    }

    private void startLiveDataNative() {
        if (liveDataRunning) return;
        liveDataRunning = true;

        liveIo.execute(() -> {
            try {
                if (!isSocketConnected()) {
                    liveDataRunning = false;
                    jsError("OBD2 is not connected.");
                    return;
                }

                Set<Integer> supported = discoverSupportedPids();

                JSONObject support = new JSONObject();
                support.put("rpm", supported.contains(0x0C));
                support.put("speed", supported.contains(0x0D));
                support.put("coolant", supported.contains(0x05));
                support.put("oilTemp", supported.contains(0x5C));
                support.put("voltage", supported.contains(0x42));
                support.put("load", supported.contains(0x04));
                support.put("throttle", supported.contains(0x11));
                support.put("intakeTemp", supported.contains(0x0F));
                support.put("map", supported.contains(0x0B));
                support.put("maf", supported.contains(0x10));
                support.put("fuelLevel", supported.contains(0x2F));
                support.put("stft1", supported.contains(0x06));
                support.put("ltft1", supported.contains(0x07));
                support.put("timing", supported.contains(0x0E));
                support.put("lambda", supported.contains(0x24) || supported.contains(0x44));
                jsCall("nativeObdLiveSupport(" + support.toString() + ")");

                // Keep RPM and speed at the front of every cycle. Only ONE slower PID
                // is read between fast cycles so gauges are never held up by a long batch.
                final int[] bgPids = {0x04,0x11,0x0B,0x10,0x0E,0x05,0x5C,0x42,0x0F,0x2F,0x06,0x07};
                final String[] bgKeys = {"load","throttle","map","maf","timing","coolant","oilTemp","voltage","intakeTemp","fuelLevel","stft1","ltft1"};
                int bgIndex = 0;
                int lambdaCounter = 0;

                while (liveDataRunning && isSocketConnected()) {
                    // Update RPM immediately after its reply.
                    JSONObject rpmData = new JSONObject();
                    putPidValue(rpmData, "rpm", 0x0C, supported);
                    if (rpmData.length() > 0) {
                        rpmData.put("ts", System.currentTimeMillis());
                        jsCall("nativeObdLiveData(" + rpmData.toString() + ")");
                    }

                    // Update speed immediately after its reply.
                    JSONObject speedData = new JSONObject();
                    putPidValue(speedData, "speed", 0x0D, supported);
                    if (speedData.length() > 0) {
                        speedData.put("ts", System.currentTimeMillis());
                        jsCall("nativeObdLiveData(" + speedData.toString() + ")");
                    }

                    // Read just one background value per cycle.
                    JSONObject bgData = new JSONObject();
                    int pid = bgPids[bgIndex];
                    putPidValue(bgData, bgKeys[bgIndex], pid, supported);
                    bgIndex = (bgIndex + 1) % bgPids.length;

                    // Lambda is useful for mixture/emissions diagnosis, but it is not CO.
                    // Try wide-range O2 equivalence ratio (PID 24) first, then commanded
                    // equivalence ratio (PID 44) as a fallback, every fourth cycle.
                    if ((lambdaCounter++ % 4) == 0) putLambdaValue(bgData, supported);

                    if (bgData.length() > 0) {
                        bgData.put("ts", System.currentTimeMillis());
                        jsCall("nativeObdLiveData(" + bgData.toString() + ")");
                    }

                    Thread.sleep(25);
                }
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            } catch (Exception e) {
                if (!isSocketConnected()) jsCall("nativeObdDisconnected()");
            } finally {
                liveDataRunning = false;
            }
        });
    }

    private Set<Integer> discoverSupportedPids() {
        Set<Integer> supported = new HashSet<>();
        addSupportedRange(supported, 0x00);
        addSupportedRange(supported, 0x20);
        addSupportedRange(supported, 0x40);

        // Some low-cost ELM327 clones do not answer support bitmaps reliably.
        // If that happens, try the most common standard PIDs directly.
        if (supported.isEmpty()) {
            int[] fallback = {0x04,0x05,0x06,0x07,0x0B,0x0C,0x0D,0x0E,0x0F,0x10,0x11,0x2F,0x42,0x5C};
            for (int pid : fallback) supported.add(pid);
        }
        return supported;
    }

    private void addSupportedRange(Set<Integer> supported, int basePid) {
        try {
            String pidHex = String.format(Locale.ROOT, "%02X", basePid);
            String raw = sendElm("01" + pidHex, 1600);
            int[] bytes = extractPidBytes(raw, basePid, 4);
            if (bytes == null || bytes.length < 4) return;

            long mask = ((long)bytes[0] << 24)
                    | ((long)bytes[1] << 16)
                    | ((long)bytes[2] << 8)
                    | (long)bytes[3];

            for (int i = 0; i < 32; i++) {
                if ((mask & (1L << (31 - i))) != 0) {
                    supported.add(basePid + i + 1);
                }
            }
        } catch (Exception ignored) {}
    }

    private void putPidValue(JSONObject data, String key, int pid, Set<Integer> supported) {
        if (!supported.contains(pid)) return;
        try {
            Double value = queryPidValue(pid);
            if (value != null && !value.isNaN() && !value.isInfinite()) {
                data.put(key, Math.round(value * 10.0) / 10.0);
            }
        } catch (Exception ignored) {}
    }

    private void putLambdaValue(JSONObject data, Set<Integer> supported) {
        try {
            Double lambda = null;
            if (supported.contains(0x24)) {
                String raw = sendElm("0124", 700);
                int[] b = extractPidBytes(raw, 0x24, 4);
                if (b != null && b.length >= 4) {
                    lambda = ((b[0] * 256.0) + b[1]) / 32768.0;
                }
            } else if (supported.contains(0x44)) {
                String raw = sendElm("0144", 700);
                int[] b = extractPidBytes(raw, 0x44, 2);
                if (b != null && b.length >= 2) {
                    lambda = ((b[0] * 256.0) + b[1]) / 32768.0;
                }
            }
            if (lambda != null && lambda > 0.0 && lambda < 4.0) {
                data.put("lambda", Math.round(lambda * 1000.0) / 1000.0);
            }
        } catch (Exception ignored) {}
    }

    private Double queryPidValue(int pid) throws Exception {
        String pidHex = String.format(Locale.ROOT, "%02X", pid);
        String raw = sendElm("01" + pidHex, 700);

        int need = (pid == 0x0C || pid == 0x10 || pid == 0x42) ? 2 : 1;
        int[] b = extractPidBytes(raw, pid, need);
        if (b == null || b.length < need) return null;

        int a = b[0];
        int bb = need > 1 ? b[1] : 0;

        switch (pid) {
            case 0x04: return a * 100.0 / 255.0;                   // engine load %
            case 0x05: return (double)a - 40.0;                   // coolant C
            case 0x06:
            case 0x07: return (a - 128.0) * 100.0 / 128.0;        // fuel trim %
            case 0x0B: return (double)a;                          // MAP kPa
            case 0x0C: return ((a * 256.0) + bb) / 4.0;           // RPM
            case 0x0D: return (double)a;                          // km/h
            case 0x0E: return a / 2.0 - 64.0;                     // timing advance deg
            case 0x0F: return (double)a - 40.0;                   // intake temp C
            case 0x10: return ((a * 256.0) + bb) / 100.0;         // MAF g/s
            case 0x11: return a * 100.0 / 255.0;                  // throttle %
            case 0x2F: return a * 100.0 / 255.0;                  // fuel level %
            case 0x42: return ((a * 256.0) + bb) / 1000.0;        // module voltage V
            case 0x5C: return (double)a - 40.0;                   // engine oil temp C
            default: return null;
        }
    }

    private int[] extractPidBytes(String raw, int pid, int count) {
        if (raw == null) return null;
        String compact = raw.toUpperCase(Locale.ROOT).replaceAll("[^0-9A-F]", "");
        String marker = "41" + String.format(Locale.ROOT, "%02X", pid);
        int pos = compact.indexOf(marker);
        if (pos < 0) return null;

        int start = pos + marker.length();
        if (compact.length() < start + count * 2) return null;

        int[] out = new int[count];
        try {
            for (int i = 0; i < count; i++) {
                out[i] = Integer.parseInt(compact.substring(start + i*2, start + i*2 + 2), 16);
            }
            return out;
        } catch (Exception e) {
            return null;
        }
    }



    private String findWorkingObdProtocol() throws Exception {
        // ELM327 protocol numbers:
        // 1 J1850 PWM, 2 J1850 VPW, 3 ISO 9141-2,
        // 4 KWP2000 5-baud init, 5 KWP2000 fast init,
        // 6 CAN 11/500, 7 CAN 29/500, 8 CAN 11/250, 9 CAN 29/250.
        // Try the most common modern CAN variants first, then KWP/ISO/J1850.
        String[][] protocols = new String[][] {
                {"6", "CAN 11-bit / 500 kbps", "4500"},
                {"7", "CAN 29-bit / 500 kbps", "4500"},
                {"8", "CAN 11-bit / 250 kbps", "4500"},
                {"9", "CAN 29-bit / 250 kbps", "4500"},
                {"5", "KWP2000 Fast Init", "6500"},
                {"4", "KWP2000 5-baud Init", "11000"},
                {"3", "ISO 9141-2", "11000"},
                {"1", "SAE J1850 PWM", "5500"},
                {"2", "SAE J1850 VPW", "5500"}
        };

        for (int i = 0; i < protocols.length; i++) {
            String id = protocols[i][0];
            String label = protocols[i][1];
            long timeout = Long.parseLong(protocols[i][2]);

            jsCall("nativeObdScanProgress("
                    + JSONObject.quote(label) + ","
                    + (i + 1) + ","
                    + protocols.length + ")");

            try {
                // Stop any previous protocol session and select this one explicitly.
                try { sendElm("ATPC", 1400); } catch (Exception ignored) {}
                sendElm("ATSP" + id, 1800);

                String probe = sendElm("0100", timeout);
                if (hasPidResponse(probe, "4100")) {
                    String detected = label;
                    try {
                        String elmName = cleanElmText(sendElm("ATDP", 1800));
                        if (!elmName.isEmpty() && !elmName.equalsIgnoreCase("AUTO")) {
                            detected = elmName;
                        }
                    } catch (Exception ignored) {}
                    return detected;
                }

                // A few ECUs/clones answer a normal live PID even when 0100 behaves oddly.
                if (!isElmConnectionFailure(probe)) {
                    try {
                        String rpmProbe = sendElm("010C", Math.min(timeout, 6000));
                        if (hasPidResponse(rpmProbe, "410C")) {
                            String detected = label;
                            try {
                                String elmName = cleanElmText(sendElm("ATDP", 1800));
                                if (!elmName.isEmpty() && !elmName.equalsIgnoreCase("AUTO")) {
                                    detected = elmName;
                                }
                            } catch (Exception ignored) {}
                            return detected;
                        }
                    } catch (Exception ignored) {}
                }
            } catch (Exception ignored) {
                // Continue with the next standard protocol.
            }
        }

        // Last fallback: let a genuine ELM327 try its own automatic search.
        jsCall("nativeObdScanProgress(" + JSONObject.quote("ELM327 Auto") + ",10,10)");
        try {
            sendElm("ATSP0", 1800);
            String autoProbe = sendElm("0100", 15000);
            if (hasPidResponse(autoProbe, "4100")) {
                String detected = "Automatic";
                try {
                    String elmName = cleanElmText(sendElm("ATDP", 1800));
                    if (!elmName.isEmpty()) detected = elmName;
                } catch (Exception ignored) {}
                return detected;
            }
        } catch (Exception ignored) {}

        return null;
    }

    private boolean hasPidResponse(String raw, String marker) {
        if (raw == null) return false;
        String upper = raw.toUpperCase(Locale.ROOT);
        if (isElmConnectionFailure(upper)) return false;
        String compact = upper.replaceAll("[^0-9A-F]", "");
        return compact.contains(marker);
    }

    private boolean isElmConnectionFailure(String raw) {
        if (raw == null) return true;
        String s = raw.toUpperCase(Locale.ROOT);
        return s.contains("UNABLE TO CONNECT")
                || s.contains("NO DATA")
                || s.contains("BUS ERROR")
                || (s.contains("BUS INIT") && s.contains("ERROR"))
                || s.contains("CAN ERROR")
                || s.contains("ERROR")
                || s.contains("STOPPED");
    }

    private String cleanElmText(String raw) {
        if (raw == null) return "";
        return raw.replace(">", " ")
                .replace("\r", " ")
                .replace("\n", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private synchronized String sendElm(String command, long timeoutMs) throws Exception {
        if (!isSocketConnected() || btIn == null || btOut == null) throw new IllegalStateException("Not connected");

        while (btIn.available() > 0) {
            byte[] junk = new byte[Math.min(512, btIn.available())];
            btIn.read(junk);
        }

        btOut.write((command + "\r").getBytes(StandardCharsets.US_ASCII));
        btOut.flush();

        StringBuilder out = new StringBuilder();
        long end = System.currentTimeMillis() + timeoutMs;
        byte[] buffer = new byte[512];
        while (System.currentTimeMillis() < end) {
            int available = btIn.available();
            if (available > 0) {
                int n = btIn.read(buffer, 0, Math.min(buffer.length, available));
                if (n > 0) {
                    out.append(new String(buffer, 0, n, StandardCharsets.US_ASCII));
                    if (out.indexOf(">") >= 0) break;
                }
            } else {
                Thread.sleep(40);
            }
        }
        if (out.length() == 0) throw new Exception("OBD timeout");
        return out.toString();
    }

    private List<String> decodeDtcs(String raw) {
        return decodeDtcsFromMode(raw, "43");
    }

    private List<String> decodeDtcsFromMode(String raw, String responseMode) {
        List<String> codes = new ArrayList<>();
        if (raw == null) return codes;

        String upper = raw.toUpperCase(Locale.ROOT)
                .replace("SEARCHING...", " ")
                .replace("SEARCHING", " ")
                .replace("NO DATA", " ")
                .replace(">", " ");
        String[] parts = upper.split("[^0-9A-F]+");
        List<String> bytes = new ArrayList<>();
        for (String p : parts) if (p.matches("[0-9A-F]{2}")) bytes.add(p);

        for (int i = 0; i < bytes.size(); i++) {
            if (!responseMode.equals(bytes.get(i))) continue;
            int j = i + 1;
            while (j + 1 < bytes.size()) {
                if (responseMode.equals(bytes.get(j))) break;
                int a, b;
                try {
                    a = Integer.parseInt(bytes.get(j), 16);
                    b = Integer.parseInt(bytes.get(j + 1), 16);
                } catch (Exception e) { break; }
                if (a == 0 && b == 0) break;
                String dtc = decodeDtcPair(a, b);
                if (dtc != null && !codes.contains(dtc)) codes.add(dtc);
                j += 2;
            }
        }
        return codes;
    }

    private String decodeDtcPair(int a, int b) {
        char[] systems = {'P','C','B','U'};
        char system = systems[(a >> 6) & 0x03];
        int digit1 = (a >> 4) & 0x03;
        int digit2 = a & 0x0F;
        int digit3 = (b >> 4) & 0x0F;
        int digit4 = b & 0x0F;
        return "" + system + digit1 + Integer.toHexString(digit2).toUpperCase(Locale.ROOT)
                + Integer.toHexString(digit3).toUpperCase(Locale.ROOT)
                + Integer.toHexString(digit4).toUpperCase(Locale.ROOT);
    }

    private boolean isSocketConnected() {
        return btSocket != null && btSocket.isConnected();
    }

    private void disconnectNative(boolean notifyJs) {
        io.execute(() -> {
            disconnectSocketOnly();
            if (notifyJs) jsCall("nativeObdDisconnected()");
        });
    }

    private void disconnectSocketOnly() {
        liveDataRunning = false;
        try { if (btIn != null) btIn.close(); } catch (Exception ignored) {}
        try { if (btOut != null) btOut.close(); } catch (Exception ignored) {}
        closeQuietly(btSocket);
        btIn = null; btOut = null; btSocket = null;
    }

    private void closeQuietly(BluetoothSocket socket) {
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
    }

    private void jsStatus(String message, boolean connected) {
        jsCall("nativeObdStatus(" + JSONObject.quote(message) + "," + connected + ")");
    }

    private void jsError(String message) {
        jsCall("nativeObdError(" + JSONObject.quote(message) + ")");
    }

    private void jsCall(String code) {
        main.post(() -> webView.evaluateJavascript("window." + code, null));
    }

    @Override protected void onDestroy() {
        stopDiscovery();
        disconnectSocketOnly();
        io.shutdownNow();
        liveIo.shutdownNow();
        if (receiverRegistered) {
            try { unregisterReceiver(btReceiver); } catch (Exception ignored) {}
        }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
